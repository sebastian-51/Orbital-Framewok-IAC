"""
Código totalmente independiente de las demas funcionalidades para verificar que la conexión a Space-Track.org
funciona ANTES de correr el código principal completo.

USO:
    1. Configura las variables de entorno (Debes de checar el readme)

       Windows (cmd):
           set SPACETRACK_USER=tu_usuario
           set SPACETRACK_PASSWORD=tu_contraseña

       Linux/macOS:
           export SPACETRACK_USER=tu_usuario
           export SPACETRACK_PASSWORD=tu_contraseña

    2. Corre este script desde la raíz del proyecto:
           python test_spacetrack_connection.py

"""
import logging
import os
import sys
import time

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

from src.tle_downloader import download_tle_from_spacetrack


def main():
    logger.info("=" * 60)
    logger.info("PRUEBA DE CONEXIÓN A SPACE-TRACK.ORG")
    logger.info("=" * 60)

    username_set = bool(os.environ.get("SPACETRACK_USER"))
    password_set = bool(os.environ.get("SPACETRACK_PASSWORD"))

    logger.info(f"SPACETRACK_USER definida: {username_set}")
    logger.info(f"SPACETRACK_PASSWORD definida: {password_set}")

    if not username_set or not password_set:
        logger.error(
            "❌ Faltan variables de entorno. Define SPACETRACK_USER y "
            "SPACETRACK_PASSWORD antes de correr este script (ver el "
            "docstring al inicio de este archivo)."
        )
        time.sleep(1)
        return

    logger.info("Intentando descargar el TLE más reciente de LANDSAT 8...")
    line1, line2 = download_tle_from_spacetrack("LANDSAT 8")
    time.sleep(1)

    if line1 is None or line2 is None:
        logger.error(
            "❌ No se pudo obtener el TLE. Revisa el mensaje de error de arriba "
            "(usuario/contraseña incorrectos, cuenta bloqueada, o problema de red)."
        )
        time.sleep(1)
        return

    logger.info("✅ ¡Conexión exitosa! TLE recibido de Space-Track.org:")
    time.sleep(0.5)
    logger.info(f"  Línea 1: {line1}")
    time.sleep(0.5)
    logger.info(f"  Línea 2: {line2}")
    time.sleep(0.5)
    logger.info("Ya puedes correr main.py con confianza de que el respaldo funciona.")
    time.sleep(0.5)


if __name__ == "__main__":
    main()
