import logging
from datetime import timedelta

import numpy as np
import pandas as pd
from sgp4.api import jday

from .coordinate_transformations import (
    ecef_to_topocentric_enu_batch,
    itrs_to_geodetic_wgs84_batch,
    teme_to_itrs_batch,
)

logger = logging.getLogger(__name__)


def propagate_orbit(tle_data, start_utc, end_utc, step_seconds, aoi_lat, aoi_lon):
    if start_utc >= end_utc:
        raise ValueError("La fecha de inicio debe ser anterior a la fecha de fin.")
    if step_seconds <= 0:
        raise ValueError("El paso temporal debe ser mayor a cero.")

    total_seconds = (end_utc - start_utc).total_seconds()
    n_steps = int(total_seconds // step_seconds) + 1
    times = [start_utc + timedelta(seconds=i * step_seconds) for i in range(n_steps)]

    logger.info(
        f"Iniciando propagación desde {start_utc.isoformat()} hasta {end_utc.isoformat()} "
        f"con paso de {step_seconds}s ({n_steps} puntos)."
    )

    jd_arr = np.empty(n_steps)
    fr_arr = np.empty(n_steps)
    for i, t in enumerate(times):
        jd, fr = jday(t.year, t.month, t.day, t.hour, t.minute, t.second + t.microsecond / 1e6)
        jd_arr[i] = jd
        fr_arr[i] = fr

    error_codes, pos_teme, vel_teme = tle_data.satrec.sgp4_array(jd_arr, fr_arr)

    valid_mask = error_codes == 0
    n_errors = int((~valid_mask).sum())
    if n_errors > 0:
        logger.warning(
            f"SGP4 reportó error en {n_errors} de {n_steps} puntos "
            f"(códigos de error distintos de 0). Se omiten esos puntos."
        )

    if not valid_mask.any():
        logger.error("No se generaron datos de propagación válidos. Verifique el TLE y el intervalo de tiempo.")
        return pd.DataFrame()

    times_arr = np.array(times, dtype=object)[valid_mask]
    pos_teme_valid = pos_teme[valid_mask]
    vel_teme_valid = vel_teme[valid_mask]

    pos_itrs = teme_to_itrs_batch(pos_teme_valid, times_arr)
    sat_lat, sat_lon, sat_alt = itrs_to_geodetic_wgs84_batch(pos_itrs)
    vel_mag = np.linalg.norm(vel_teme_valid, axis=1)
    az_deg, el_deg, slant_range_km = ecef_to_topocentric_enu_batch(
        pos_itrs, aoi_lat, aoi_lon, aoi_alt_km=0.0
    )

    df = pd.DataFrame({
        'utc_time': pd.to_datetime(times_arr),
        'pos_itrs_km': list(pos_itrs),
        'sat_lat_deg': sat_lat,
        'sat_lon_deg': sat_lon,
        'sat_alt_km': sat_alt,
        'sat_vel_km_s': vel_mag,
        'azimuth_deg': az_deg,
        'elevation_deg': el_deg,
        'slant_range_km': slant_range_km,
        'tle_epoch_utc': tle_data.epoch_utc,
        'norad_id': tle_data.norad_id,
    })

    logger.info(f"Propagación completada. {len(df)} puntos de datos generados.")
    return df
