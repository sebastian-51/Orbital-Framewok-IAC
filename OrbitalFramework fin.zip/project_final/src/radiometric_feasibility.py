import logging

import numpy as np

logger = logging.getLogger(__name__)


def evaluate_radiometric_feasibility(solar_elevation_deg, illumination_status,
                                     glint_risk, cloud_cover_percent=None):
    radiometric_status = "Unknown"
    shadow_risk = "Not evaluated"
    saturation_risk = "Not evaluated"
    cloud_status = "Not evaluated"

    if illumination_status == "Daylight":
        radiometric_status = "Illuminated"
        if solar_elevation_deg < 30.0:
            shadow_risk = "High"
        elif solar_elevation_deg < 45.0:
            shadow_risk = "Medium"
        else:
            shadow_risk = "Low"
    elif "Twilight" in illumination_status:
        radiometric_status = "Low_Illumination"
        shadow_risk = "Extreme"
    else:
        radiometric_status = "Dark"
        shadow_risk = "Not applicable"

    if glint_risk == "High":
        saturation_risk = "High (Specular Glint)"
    elif glint_risk == "Medium":
        saturation_risk = "Medium (Potential Glint)"
    elif glint_risk == "Low":
        saturation_risk = "Low"
    else:
        saturation_risk = "Not evaluated"

    if cloud_cover_percent is not None and not np.isnan(cloud_cover_percent):
        if cloud_cover_percent > 80.0:
            cloud_status = "Obscured"
        elif cloud_cover_percent > 30.0:
            cloud_status = "Partially Cloudy"
        else:
            cloud_status = "Clear"

    return {
        'radiometric_status': radiometric_status,
        'shadow_risk': shadow_risk,
        'saturation_risk': saturation_risk,
        'cloud_status': cloud_status
    }
