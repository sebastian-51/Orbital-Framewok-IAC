import logging
import numpy as np
logger = logging.getLogger(__name__)
EARTH_RADIUS_KM = 6371.0

def calculate_off_nadir_angle(sat_ecef_km, aoi_ecef_km, sat_lat_deg=None, sat_lon_deg=None):
    los_vector = aoi_ecef_km - sat_ecef_km
    los_norm = np.linalg.norm(los_vector)

    if los_norm == 0:
        return 0.0

    los_unit = los_vector / los_norm

    if sat_lat_deg is not None and sat_lon_deg is not None:
        lat = np.radians(sat_lat_deg)
        lon = np.radians(sat_lon_deg)
        up_geodetic = np.array([
            np.cos(lat) * np.cos(lon),
            np.cos(lat) * np.sin(lon),
            np.sin(lat)
        ])
        nadir_unit = -up_geodetic
    else:
        nadir_vector = -sat_ecef_km
        nadir_norm = np.linalg.norm(nadir_vector)
        nadir_unit = nadir_vector / nadir_norm

    dot_product = np.clip(np.dot(los_unit, nadir_unit), -1.0, 1.0)
    angle_rad = np.arccos(dot_product)

    return np.degrees(angle_rad)

def calculate_off_nadir_angle_batch(sat_ecef_km_array, aoi_ecef_km, sat_lat_deg=None, sat_lon_deg=None):
    los_vector = aoi_ecef_km - sat_ecef_km_array  # (N, 3)
    los_norm = np.linalg.norm(los_vector, axis=1)
    los_norm_safe = np.where(los_norm == 0, 1.0, los_norm)
    los_unit = los_vector / los_norm_safe[:, None]

    if sat_lat_deg is not None and sat_lon_deg is not None:
        lat = np.radians(np.asarray(sat_lat_deg))
        lon = np.radians(np.asarray(sat_lon_deg))
        up_geodetic = np.column_stack([
            np.cos(lat) * np.cos(lon),
            np.cos(lat) * np.sin(lon),
            np.sin(lat)
        ])
        nadir_unit = -up_geodetic
    else:
        nadir_vector = -sat_ecef_km_array
        nadir_norm = np.linalg.norm(nadir_vector, axis=1)
        nadir_unit = nadir_vector / nadir_norm[:, None]

    dot_product = np.clip(np.sum(los_unit * nadir_unit, axis=1), -1.0, 1.0)
    return np.degrees(np.arccos(dot_product))

def haversine_distance_km(lat1_deg, lon1_deg, lat2_deg, lon2_deg):
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1_deg, lon1_deg, lat2_deg, lon2_deg])

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = np.sin(dlat/2.0)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2.0)**2
    c = 2 * np.arcsin(np.sqrt(a))
    return EARTH_RADIUS_KM * c

def estimate_aoi_coverage_percent(ground_distance_km, swath_width_km, aoi_radius_km):
    half_swath = swath_width_km / 2.0
    if ground_distance_km >= half_swath + aoi_radius_km:
        return 0.0
    if ground_distance_km <= half_swath - aoi_radius_km:
        return 100.0
    area_circle = np.pi * aoi_radius_km**2
    if ground_distance_km <= half_swath:
        d_edge = half_swath - ground_distance_km
        if d_edge >= aoi_radius_km:
            return 100.0
        area_uncovered = (aoi_radius_km**2) * np.arccos(d_edge / aoi_radius_km) - \
                         d_edge * np.sqrt(aoi_radius_km**2 - d_edge**2)
        area_covered = area_circle - area_uncovered
    else:
        d_edge = ground_distance_km - half_swath
        if d_edge >= aoi_radius_km:
            return 0.0
        area_covered = (aoi_radius_km**2) * np.arccos(d_edge / aoi_radius_km) - \
                       d_edge * np.sqrt(aoi_radius_km**2 - d_edge**2)

    coverage_percent = (area_covered / area_circle) * 100.0
    return np.clip(coverage_percent, 0.0, 100.0)