import logging
from datetime import datetime, timedelta, timezone
from sgp4.api import WGS84, Satrec
logger = logging.getLogger(__name__)

def validate_tle_checksum(line):
    """Valida el checksum (módulo 10) de una línea TLE."""
    if len(line) != 69:
        return False

    checksum_digit = int(line[-1])
    calculated_sum = 0

    for char in line[:-1]:
        if char.isdigit():
            calculated_sum += int(char)
        elif char == '-':
            calculated_sum += 1

    return (calculated_sum % 10) == checksum_digit

def parse_tle_epoch(line1):
    """Extrae la época del TLE y la convierte a datetime UTC."""
    epoch_year = int(line1[18:20])
    epoch_day = float(line1[20:32])

    if epoch_year < 57:
        year = 2000 + epoch_year
    else:
        year = 1900 + epoch_year

    dt = datetime(year, 1, 1, tzinfo=timezone.utc) + timedelta(days=epoch_day - 1)
    return dt

class TLEData:
    def __init__(self, line1, line2, epoch_utc, satrec, norad_id):
        self.line1 = line1
        self.line2 = line2
        self.epoch_utc = epoch_utc
        self.satrec = satrec
        self.norad_id = norad_id


def load_and_validate_tle(line1, line2, current_utc_time):
    """
    Carga, valida y prepara el TLE para SGP4.
    """
    line1 = line1.strip()
    line2 = line2.strip()

    if not validate_tle_checksum(line1):
        raise ValueError("Error: El checksum de la Línea 1 del TLE es inválido.")
    if not validate_tle_checksum(line2):
        raise ValueError("Error: El checksum de la Línea 2 del TLE es inválido.")

    try:
        satrec = Satrec.twoline2rv(line1, line2, WGS84)
    except Exception as e:
        raise ValueError(f"Error al inicializar SGP4 con el TLE proporcionado: {e}") from e

    epoch_utc = parse_tle_epoch(line1)
    norad_id = int(line1[2:7].strip())

    tle_age_days = (current_utc_time - epoch_utc).total_seconds() / 86400.0

    logger.info(f"TLE cargado para NORAD ID {norad_id}. Época: {epoch_utc.isoformat()}. Antigüedad: {tle_age_days:.2f} días.")

    return TLEData(line1, line2, epoch_utc, satrec, norad_id), tle_age_days
