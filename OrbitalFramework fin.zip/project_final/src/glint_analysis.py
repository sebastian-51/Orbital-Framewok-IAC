import logging
import numpy as np
logger = logging.getLogger(__name__)

def calculate_glint_angle_and_risk(sun_unit_enu, sensor_unit_enu, glint_thresholds):
    n_vec = np.array([0.0, 0.0, 1.0])
    if np.dot(sun_unit_enu, n_vec) <= 0:
        logger.debug("Sol bajo el horizonte. Glint geométrico no aplicable.")
        return np.nan, "Not evaluated (Night)"
    s_dot_n = np.dot(sun_unit_enu, n_vec)
    reflection_vec = 2.0 * s_dot_n * n_vec - sun_unit_enu
    reflection_vec_norm = np.linalg.norm(reflection_vec)
    if reflection_vec_norm == 0:
        return np.nan, "Not evaluated"
    reflection_unit = reflection_vec / reflection_vec_norm
    v_dot_r = np.clip(np.dot(sensor_unit_enu, reflection_unit), -1.0, 1.0)
    glint_angle_rad = np.arccos(v_dot_r)
    glint_angle_deg = np.degrees(glint_angle_rad)
    high_thresh = glint_thresholds['risk_levels']['high']   # ej. ángulo < 30° => High
    med_thresh = glint_thresholds['risk_levels']['medium']  # ej. 30°-45° => Medium

    if high_thresh >= med_thresh:
        logger.warning(
            f"Configuración de glint_analysis.risk_levels inconsistente: "
            f"'high' ({high_thresh}) debería ser MENOR que 'medium' ({med_thresh}). "
            "El nivel 'High' puede quedar inalcanzable. Revise config_settings.yaml."
        )

    if glint_angle_deg < high_thresh:
        risk_level = "High"
    elif glint_angle_deg < med_thresh:
        risk_level = "Medium"
    else:
        risk_level = "Low"

    return glint_angle_deg, risk_level


def get_sensor_unit_vector_from_aoi(azimuth_deg, elevation_deg):
    az_rad = np.radians(azimuth_deg)
    el_rad = np.radians(elevation_deg)

    e = np.cos(el_rad) * np.sin(az_rad)
    n = np.cos(el_rad) * np.cos(az_rad)
    u = np.sin(el_rad)

    return np.array([e, n, u])
