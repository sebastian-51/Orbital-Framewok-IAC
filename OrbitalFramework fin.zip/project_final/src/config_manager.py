import logging
import os
import yaml
logger = logging.getLogger(__name__)

def load_yaml(file_path):
    #Carga un archivo YAML de forma segura.
    if not os.path.exists(file_path):
        logger.error(f"Archivo de configuración no encontrado: {file_path}")
        raise FileNotFoundError(f"El archivo {file_path} no existe.")

    with open(file_path, 'r', encoding='utf-8') as f:
        try:
            return yaml.safe_load(f)
        except yaml.YAMLError as e:
            logger.error(f"Error al parsear YAML {file_path}: {e}")
            raise
def get_settings():
    return load_yaml('config/config_settings.yaml')
def get_sensors():
    return load_yaml('config/sensors.yaml')
