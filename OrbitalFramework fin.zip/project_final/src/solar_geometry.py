import logging

import astropy.units as u
import numpy as np
from astropy.coordinates import ITRS, get_sun
from astropy.time import Time

from .coordinate_transformations import WGS84_A, WGS84_E2

logger = logging.getLogger(__name__)

def get_local_enu_matrix(lat_deg, lon_deg):
    """
    Genera la matriz de rotación de ECEF a ENU (East-North-Up) para un punto en la superficie.
    """
    lat = np.radians(lat_deg)
    lon = np.radians(lon_deg)

    # Matriz de rotación ECEF -> ENU
    R = np.array([
        [-np.sin(lon), np.cos(lon), 0],
        [-np.sin(lat)*np.cos(lon), -np.sin(lat)*np.sin(lon), np.cos(lat)],
        [np.cos(lat)*np.cos(lon), np.cos(lat)*np.sin(lon), np.sin(lat)]
    ])
    return R
def get_sun_vector_enu(time_utc, aoi_lat_deg, aoi_lon_deg):
    """
    Calcula el vector unitario hacia el Sol, en el sistema local ENU
    (East-North-Up), visto desde una AOI en la superficie terrestre.
    """
    t = Time(time_utc)
    sun_gcrs = get_sun(t)
    sun_itrs = sun_gcrs.transform_to(ITRS(obstime=t))
    sun_ecef_km = sun_itrs.cartesian.xyz.to(u.km).value
    lat = np.radians(aoi_lat_deg)
    lon = np.radians(aoi_lon_deg)
    N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    aoi_ecef_km = np.array([
        N * np.cos(lat) * np.cos(lon),
        N * np.cos(lat) * np.sin(lon),
        N * (1 - WGS84_E2) * np.sin(lat)
    ])

    sun_vector_ecef = sun_ecef_km - aoi_ecef_km
    sun_vector_ecef_norm = np.linalg.norm(sun_vector_ecef)

    if sun_vector_ecef_norm == 0:
        raise ValueError("Error: Vector solar nulo.")

    sun_unit_ecef = sun_vector_ecef / sun_vector_ecef_norm

    R_enu = get_local_enu_matrix(aoi_lat_deg, aoi_lon_deg)
    return R_enu @ sun_unit_ecef

def calculate_solar_geometry(time_utc, aoi_lat_deg, aoi_lon_deg, sensor_azimuth_deg):
    """
    Calcula la geometría solar completa para un instante y ubicación dados.
    """
    sun_unit_enu = get_sun_vector_enu(time_utc, aoi_lat_deg, aoi_lon_deg)
    e_sun, n_sun, u_sun = sun_unit_enu
    cos_sza = np.clip(u_sun, -1.0, 1.0)
    sza_rad = np.arccos(cos_sza)
    sza_deg = np.degrees(sza_rad)
    sol_elev_deg = 90.0 - sza_deg
    sol_az_rad = np.arctan2(e_sun, n_sun)
    sol_az_deg = np.degrees(sol_az_rad) % 360.0

    rel_az_deg = (sol_az_deg - sensor_azimuth_deg + 180.0) % 360.0 - 180.0

    if sol_elev_deg > 0.0:
        illumination_status = "Daylight"
    elif sol_elev_deg > -6.0:
        illumination_status = "Civil Twilight"
    elif sol_elev_deg > -12.0:
        illumination_status = "Nautical Twilight"
    elif sol_elev_deg > -18.0:
        illumination_status = "Astronomical Twilight"
    else:
        illumination_status = "Night"
    if not np.isclose(sza_deg + sol_elev_deg, 90.0, atol=1e-6):
        logger.warning(f"Inconsistencia numérica detectada: SZA ({sza_deg}) + Elevación ({sol_elev_deg}) != 90.")

    return {
        'solar_zenith_angle_deg': sza_deg,
        'solar_elevation_deg': sol_elev_deg,
        'solar_azimuth_deg': sol_az_deg,
        'relative_azimuth_deg': rel_az_deg,
        'illumination_status': illumination_status
    }
