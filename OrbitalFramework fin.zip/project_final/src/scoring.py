import logging
import numpy as np
logger = logging.getLogger(__name__)
def _calculate_coverage_score(coverage_percent, min_coverage):
    """Puntuación de cobertura: 0 si es < min_coverage, 100 si es 100%. Lineal en medio."""
    if coverage_percent < min_coverage:
        return 0.0
    if coverage_percent >= 100.0:
        return 100.0
    # Interpolación lineal entre min_coverage y 100
    return 100.0 * (coverage_percent - min_coverage) / (100.0 - min_coverage)


def _calculate_solar_score(sza_deg, max_sza):
    """Puntuación de geometría solar: 100 si SZA=0, 0 si SZA >= max_sza."""
    if sza_deg <= 0.0:
        return 100.0
    if sza_deg >= max_sza:
        return 0.0
    # Menor SZA es mejor. Interpolación lineal.
    return 100.0 * (max_sza - sza_deg) / max_sza


def _calculate_viewing_score(off_nadir_deg, max_off_nadir):
    """Puntuación de ángulo de visión: 100 si off-nadir=0, 0 si >= max_off_nadir."""
    if off_nadir_deg <= 0.0:
        return 100.0
    if off_nadir_deg >= max_off_nadir:
        return 0.0
    # Menor off-nadir es mejor.
    return 100.0 * (max_off_nadir - off_nadir_deg) / max_off_nadir


def _calculate_glint_score(glint_risk):
    """Puntuación de riesgo de glint: Función escalón."""
    if glint_risk == "Low":
        return 100.0
    elif glint_risk == "Medium":
        return 50.0
    elif glint_risk == "High":
        return 0.0
    else: 
        return 50.0 


def _calculate_tle_score(tle_age_days, max_tle_age):
    """Puntuación de frescura del TLE: 100 si age=0, 0 si age >= max_age."""
    if tle_age_days <= 0.0:
        return 100.0
    if tle_age_days >= max_tle_age:
        return 0.0
    return 100.0 * (max_tle_age - tle_age_days) / max_tle_age

def calculate_feasibility_scores(window_data, sensor_config, settings):
    geom_criteria = settings['geometry_criteria']
    weights = settings['scoring_weights']
    classes = settings['feasibility_classes']
    critical_criteria = settings.get('critical_rejection_criteria', [
        "aoi_out_of_swath",
        "solar_elevation_below_minimum",
        "off_nadir_exceeds_sensor_limit",
        "nighttime_for_passive_optical",
    ])

    cov_score = _calculate_coverage_score(
        window_data['AOI_Coverage_percent'],
        geom_criteria['min_aoi_coverage_percent']
    )

    solar_score = _calculate_solar_score(
        window_data['Solar_Zenith_Angle_deg'],
        geom_criteria['max_solar_zenith_angle_deg']
    )

    view_score = _calculate_viewing_score(
        window_data['Off_Nadir_Angle_deg'],
        sensor_config['max_off_nadir_angle_deg']
    )

    glint_score = _calculate_glint_score(window_data['Sun_Glint_Risk'])

    tle_score = _calculate_tle_score(
        window_data['TLE_Age_days'],
        geom_criteria['max_tle_age_days']
    )

    total_weight = sum(weights.values())
    if not np.isclose(total_weight, 100.0, atol=0.1):
        logger.warning(f"Los pesos de scoring suman {total_weight}, no 100. Se normalizarán.")

    weighted_sum = (
        (cov_score * weights['coverage']) +
        (solar_score * weights['solar_geometry']) +
        (view_score * weights['viewing_angle']) +
        (glint_score * weights['sun_glint']) +
        (tle_score * weights['tle_freshness'])
    )
    overall_score = weighted_sum / total_weight

    overall_score = np.clip(overall_score, 0.0, 100.0)

    candidate_reasons = []
    warnings = []
    if window_data['AOI_Coverage_percent'] < geom_criteria['min_aoi_coverage_percent']:
        candidate_reasons.append("aoi_out_of_swath")
    if window_data['Solar_Elevation_deg'] < geom_criteria['min_solar_elevation_deg']:
        candidate_reasons.append("solar_elevation_below_minimum")
    if window_data['Off_Nadir_Angle_deg'] > sensor_config['max_off_nadir_angle_deg']:
        candidate_reasons.append("off_nadir_exceeds_sensor_limit")
    if sensor_config.get('is_passive_optical', True) and window_data['Illumination_Status'] == "Night":
        candidate_reasons.append("nighttime_for_passive_optical")

    rejection_reasons = [r for r in candidate_reasons if r in critical_criteria]

    if rejection_reasons:
        feasibility_class = "Not Viable"
        reason_text = "Critical: " + ", ".join(rejection_reasons)
    else:
        if overall_score >= classes['viable_min_score']:
            feasibility_class = "Viable"
            reason_text = "Meets all geometric and radiometric criteria."
        elif overall_score >= classes['conditional_min_score']:
            feasibility_class = "Conditional"
            # Generar advertencias basadas en puntuaciones bajas
            if cov_score < 80: warnings.append("Sub-optimal coverage")
            if solar_score < 80: warnings.append("Sub-optimal solar geometry")
            if view_score < 80: warnings.append("High off-nadir angle")
            if glint_score < 100: warnings.append("Glint risk present")

            reason_text = "Warning: " + ", ".join(warnings) if warnings else "Marginal scores."
        else:
            feasibility_class = "Not Viable"
            reason_text = f"Overall score ({overall_score:.1f}) below conditional threshold."

    if feasibility_class == "Viable":
        action = "Proceed with acquisition planning."
    elif feasibility_class == "Conditional":
        action = "Review specific warnings. Consider alternative passes if available."
    else:
        action = "Reject pass. Seek alternative dates or sensors."
    illumination_reasons = {"solar_elevation_below_minimum", "nighttime_for_passive_optical"}
    geom_weight_sum = weights['coverage'] + weights['viewing_angle']
    if geom_weight_sum > 0:
        geometric_quality_score = (
            (cov_score * weights['coverage']) + (view_score * weights['viewing_angle'])
        ) / geom_weight_sum
    else:
        geometric_quality_score = 0.0
    geometric_quality_score = round(float(np.clip(geometric_quality_score, 0.0, 100.0)), 2)

    if feasibility_class != "Not Viable":
        rejection_category = "N/A"
    elif not rejection_reasons:
        rejection_category = "Low_Score"
    elif set(rejection_reasons).issubset(illumination_reasons):
        rejection_category = "Illumination_Only"
    else:
        rejection_category = "Geometric"
    illumination_limited_opportunity = bool(
        rejection_category == "Illumination_Only"
        and geometric_quality_score >= classes['viable_min_score']
    )

    return {
        'Coverage_Score': round(cov_score, 2),
        'Geometry_Score': round(solar_score, 2),
        'Viewing_Score': round(view_score, 2),
        'Glint_Score': round(glint_score, 2),
        'TLE_Score': round(tle_score, 2),
        'Geometric_Quality_Score': geometric_quality_score,
        'Rejection_Category': rejection_category,
        'Illumination_Limited_Opportunity': illumination_limited_opportunity,
        'Overall_Score': round(overall_score, 2),
        'Feasibility_Class': feasibility_class,
        'Rejection_Reason': reason_text,
        'Recommended_Action': action
    }
