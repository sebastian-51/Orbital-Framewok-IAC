import logging
import numpy as np
import pandas as pd
from .coordinate_transformations import WGS84_A, WGS84_E2
from .sensor_coverage import (
    calculate_off_nadir_angle_batch,
    estimate_aoi_coverage_percent,
    haversine_distance_km,
)

logger = logging.getLogger(__name__)

def _get_aoi_ecef(lat_deg, lon_deg, alt_km=0.0):
    lat = np.radians(lat_deg)
    lon = np.radians(lon_deg)
    N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    return np.array([
        (N + alt_km) * np.cos(lat) * np.cos(lon),
        (N + alt_km) * np.cos(lat) * np.sin(lon),
        (N * (1 - WGS84_E2) + alt_km) * np.sin(lat)
    ])

def detect_acquisition_windows(df_propagated, sensor_config, aoi_config, step_seconds=None):
    if df_propagated.empty:
        return pd.DataFrame()

    if 'pos_itrs_km' not in df_propagated.columns:
        raise KeyError(
            "El DataFrame de propagación debe contener 'pos_itrs_km'. "
            "Verifique que está usando la versión actual de orbit_propagator.py."
        )

    max_off_nadir = sensor_config['max_off_nadir_angle_deg']
    swath_width = sensor_config['swath_width_km']
    aoi_radius = aoi_config.get('radius_km', 0.0)

    aoi_ecef = _get_aoi_ecef(aoi_config['lat'], aoi_config['lon'])

    logger.info(f"Calculando geometría de cobertura para {len(df_propagated)} puntos. Max Off-Nadir: {max_off_nadir}°")
    pos_itrs_arr = np.vstack(df_propagated['pos_itrs_km'].values)

    off_nadir_angles = calculate_off_nadir_angle_batch(
        pos_itrs_arr, aoi_ecef,
        sat_lat_deg=df_propagated['sat_lat_deg'].values,
        sat_lon_deg=df_propagated['sat_lon_deg'].values,
    )

    ground_distances = haversine_distance_km(
        df_propagated['sat_lat_deg'].values, df_propagated['sat_lon_deg'].values,
        aoi_config['lat'], aoi_config['lon']
    )
    coverages = np.array([
        estimate_aoi_coverage_percent(g_dist, swath_width, aoi_radius)
        for g_dist in ground_distances
    ])

    df_propagated = df_propagated.copy()
    df_propagated['off_nadir_deg'] = off_nadir_angles
    df_propagated['ground_distance_km'] = ground_distances
    df_propagated['coverage_percent'] = coverages
    df_valid = df_propagated[df_propagated['coverage_percent'] > 0.0].copy()

    if df_valid.empty:
        logger.info("No se detectaron ventanas de adquisición. La AOI no cruza el swath.")
        return pd.DataFrame()
    time_diffs = df_valid['utc_time'].diff().dt.total_seconds()

    if step_seconds is None:
        step_seconds = time_diffs.median()
        logger.warning(
            "step_seconds no fue provisto explícitamente a detect_acquisition_windows(); "
            f"se infirió {step_seconds}s a partir de los datos, lo cual puede ser "
            "poco fiable si hay pocas muestras por pasada."
        )

    df_valid['is_new_window'] = time_diffs > (1.5 * step_seconds)
    df_valid['window_group'] = df_valid['is_new_window'].cumsum()

    windows_data = []
    window_id = 1

    for group_id, group_df in df_valid.groupby('window_group'):
        start_time = group_df['utc_time'].iloc[0]
        end_time = group_df['utc_time'].iloc[-1]
        duration_sec = (end_time - start_time).total_seconds()

        idx_max_elev = group_df['elevation_deg'].idxmax()
        closest_approach_time = group_df.loc[idx_max_elev, 'utc_time']
        max_elevation = group_df.loc[idx_max_elev, 'elevation_deg']
        min_distance = group_df['ground_distance_km'].min()

        off_nadir_at_closest = group_df.loc[idx_max_elev, 'off_nadir_deg']
        az_at_closest = group_df.loc[idx_max_elev, 'azimuth_deg']
        vel_at_closest = group_df.loc[idx_max_elev, 'sat_vel_km_s']

        lat_diff = group_df['sat_lat_deg'].iloc[-1] - group_df['sat_lat_deg'].iloc[0]
        orbit_dir = "Ascending" if lat_diff > 0 else "Descending"

        max_coverage = group_df['coverage_percent'].max()
        if max_coverage >= 99.9:
            cov_status = "Complete"
        elif max_coverage > 0:
            cov_status = "Partial"
        else:
            cov_status = "Insufficient"

        windows_data.append({
            'Window_ID': f"W_{window_id:04d}",
            'Window_Start_UTC': start_time,
            'Closest_Approach_UTC': closest_approach_time,
            'Window_End_UTC': end_time,
            'Duration_seconds': duration_sec,
            'Orbit_Direction': orbit_dir,
            'Max_Elevation_deg': max_elevation,
            'Ground_Distance_km': min_distance,
            'Off_Nadir_Angle_deg': off_nadir_at_closest,
            'Azimuth_deg': az_at_closest,
            'AOI_Coverage_percent': max_coverage,
            'Coverage_Status': cov_status,
            'Satellite_Latitude_deg': group_df.loc[idx_max_elev, 'sat_lat_deg'],
            'Satellite_Longitude_deg': group_df.loc[idx_max_elev, 'sat_lon_deg'],
            'Satellite_Altitude_km': group_df.loc[idx_max_elev, 'sat_alt_km'],
            'Satellite_Velocity_km_s': vel_at_closest,
        })
        window_id += 1

    df_windows = pd.DataFrame(windows_data)
    logger.info(f"Detección completada. Se encontraron {len(df_windows)} ventanas de adquisición candidatas.")

    return df_windows
