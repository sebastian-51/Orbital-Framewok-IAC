import logging
import sys
from datetime import datetime, timezone
import astropy
import numpy as np
import pandas as pd
import sgp4
import xlsxwriter

logger = logging.getLogger(__name__)

REQUIRED_COLUMNS = [
    'Window_ID', 'Run_ID', 'Satellite', 'NORAD_ID', 'Sensor', 'AOI_Name',
    'AOI_Latitude_deg', 'AOI_Longitude_deg', 'Window_Start_UTC', 'Closest_Approach_UTC',
    'Window_End_UTC', 'Duration_seconds', 'Orbit_Direction', 'Satellite_Latitude_deg',
    'Satellite_Longitude_deg', 'Satellite_Altitude_km', 'Satellite_Velocity_km_s',
    'Ground_Distance_km', 'Max_Elevation_deg', 'Azimuth_deg', 'TLE_Epoch_UTC',
    'TLE_Age_days', 'Viewing_Angle_deg', 'Incidence_Angle_deg', 'Off_Nadir_Angle_deg',
    'Swath_Width_km', 'AOI_Coverage_percent', 'Coverage_Status', 'Spatial_Resolution_m',
    'Solar_Zenith_Angle_deg', 'Solar_Elevation_deg', 'Solar_Azimuth_deg',
    'Relative_Azimuth_deg', 'Phase_Angle_deg', 'Glint_Angle_deg', 'Sun_Glint_Risk',
    'Daylight_Status', 'Illumination_Status', 'Radiometric_Status',
    'Shadow_Risk', 'Saturation_Risk', 'Cloud_Status',
    'Geometry_Score', 'Coverage_Score', 'Viewing_Score', 'Glint_Score', 'TLE_Score',
    'Geometric_Quality_Score', 'Rejection_Category', 'Illumination_Limited_Opportunity',
    'Overall_Score', 'Feasibility_Class',
    'Rejection_Reason', 'Recommended_Action', 'Confidence_Level', 'Catalog_Checked',
    'Product_Found', 'Product_ID', 'Actual_Acquisition_UTC', 'Time_Error_seconds',
    'Position_Error_km', 'Product_URL', 'Validation_Status'
]

CATEGORICAL_COLOR_MAPS = {
    'Feasibility_Class': {
        'exact': True,
        'colors': {
            'Viable': ('#C6EFCE', '#006100'),
            'Conditional': ('#FFEB9C', '#9C6500'),
            'Not Viable': ('#FFC7CE', '#9C0006'),
        },
    },
    'Coverage_Status': {
        'exact': True,
        'colors': {
            'Complete': ('#C6EFCE', '#006100'),
            'Partial': ('#FFEB9C', '#9C6500'),
            'Insufficient': ('#FFC7CE', '#9C0006'),
        },
    },
    'Sun_Glint_Risk': {
        'exact': True,
        'colors': {
            'Low': ('#C6EFCE', '#006100'),
            'Medium': ('#FFEB9C', '#9C6500'),
            'High': ('#FFC7CE', '#9C0006'),
        },
    },
    'Shadow_Risk': {
        'exact': True,
        'colors': {
            'Low': ('#C6EFCE', '#006100'),
            'Medium': ('#FFEB9C', '#9C6500'),
            'High': ('#FFC7CE', '#9C0006'),
            'Extreme': ('#FFC7CE', '#9C0006'),
        },
    },
    'Saturation_Risk': {
        'exact': False,  
        'colors': {
            'Low': ('#C6EFCE', '#006100'),
            'Medium': ('#FFEB9C', '#9C6500'),
            'High': ('#FFC7CE', '#9C0006'),
        },
    },
    'Illumination_Status': {
        'exact': False,  
        'colors': {
            'Daylight': ('#FFF2CC', '#7F6000'),
            'Twilight': ('#FCE4D6', '#843C0C'),
            'Night': ('#D9D9D9', '#404040'),
        },
    },
    'Rejection_Category': {
        'exact': True,
        'colors': {
            'Illumination_Only': ('#BDD7EE', '#1F4E78'),
            'Geometric': ('#FFC7CE', '#9C0006'),
            'Low_Score': ('#FFEB9C', '#9C6500'),
            'N/A': ('#D9D9D9', '#595959'),
        },
    },
    'Illumination_Limited_Opportunity': {
        'exact': True,
        'colors': {
            'True': ('#BDD7EE', '#1F4E78'),
        },
    },
}


def _column_width(col_name):
    if col_name in ('Rejection_Reason', 'Recommended_Action'):
        return 34
    if 'UTC' in col_name or 'Epoch' in col_name:
        return 19
    if col_name in ('Window_ID', 'Run_ID', 'Product_ID', 'Product_URL'):
        return 16
    if col_name in ('Satellite', 'Sensor', 'AOI_Name'):
        return 20
    if any(x in col_name for x in ('Status', 'Class', 'Risk', 'Direction')):
        return 15
    if any(x in col_name for x in ('_deg', '_km', '_m', '_s', 'percent', 'Score', 'Age')):
        return 13
    return 14

def _column_needs_decimal_format(col_name):
    return any(x in col_name for x in ('_deg', '_km', '_m', '_s', 'percent', 'Score', 'Age'))

def _column_is_date(col_name):
    return 'UTC' in col_name or 'Epoch' in col_name
class ExcelExporter:
    def __init__(self, output_path, framework_version="1.0.0"):
        self.output_path = output_path
        self.framework_version = framework_version
        self.workbook = None
        self._init_formats()
    def _init_formats(self):
        """Comienza los formatos de celda."""
    def _create_formats(self, workbook):
        self.header_fmt = workbook.add_format({
            'bold': True, 'bg_color': '#1F4E78', 'font_color': 'white',
            'border': 1, 'text_wrap': True, 'valign': 'vcenter', 'align': 'center'
        })
        self.date_fmt = workbook.add_format({'num_format': 'yyyy-mm-dd hh:mm:ss'})
        self.num_fmt_2 = workbook.add_format({'num_format': '0.00'})
        self.num_fmt_0 = workbook.add_format({'num_format': '0'})

        self.fmt_viable = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100', 'bold': True})
        self.fmt_conditional = workbook.add_format({'bg_color': '#FFEB9C', 'font_color': '#9C6500', 'bold': True})
        self.fmt_not_viable = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006', 'bold': True})
        self.fmt_na = workbook.add_format({'bg_color': '#D9D9D9', 'font_color': '#595959', 'italic': True})

        self.title_fmt = workbook.add_format({
            'bold': True, 'font_size': 16, 'font_color': 'white', 'bg_color': '#1F4E78',
            'valign': 'vcenter', 'indent': 1
        })
        self.subtitle_fmt = workbook.add_format({
            'bold': True, 'font_size': 11, 'font_color': '#1F4E78', 'bg_color': '#DCE6F1',
            'valign': 'vcenter', 'indent': 1
        })
        self.info_fmt = workbook.add_format({
            'font_size': 10, 'font_color': '#404040', 'bg_color': '#F2F2F2',
            'valign': 'vcenter', 'indent': 1
        })
        self.kpi_label_fmt_base = {
            'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 1, 'font_size': 10
        }
        self.kpi_value_fmt_base = {
            'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 1, 'font_size': 20
        }

    def generate_report(self, df_windows, input_params, sensor_configs, settings):
        logger.info(f"Iniciando generación de reporte Excel en {self.output_path}")
        df_windows = self._ensure_columns(df_windows)
        self.workbook = xlsxwriter.Workbook(self.output_path, {
            'remove_timezone': True,
            'nan_inf_to_errors': True
        })
        self._create_formats(self.workbook)
        try:
            self._write_acquisition_windows(df_windows)
            self._write_dashboard(df_windows, input_params)
            self._write_night_opportunities(df_windows)
            self._write_input_parameters(input_params)
            self._write_criteria(settings)
            self._write_geometric_analysis(df_windows)
            self._write_radiometric_analysis(df_windows)
            self._write_catalog_validation(df_windows)
            self._write_satellite_sensors(sensor_configs)
            self._write_methodology()
            self.workbook.worksheets_objs.sort(
                key=lambda ws: 0 if ws.get_name() == 'Dashboard' else 1
            )

            self.workbook.close()
            logger.info("Reporte Excel generado exitosamente.")
            return True
        except Exception as e: 
            logger.error(f"Error fatal al generar el Excel: {e}")
            if self.workbook and not getattr(self.workbook, 'fileclosed', False):
                self.workbook.close()
            return False

    def _ensure_columns(self, df):
        """Asegura que todas las columnas requeridas existan, rellenando con NaN si faltan."""
        if df is None or df.empty:
            return pd.DataFrame(columns=REQUIRED_COLUMNS)

        for col in REQUIRED_COLUMNS:
            if col not in df.columns:
                df[col] = np.nan
        return df[REQUIRED_COLUMNS]

    def _write_dataframe_table(self, ws, df, table_style='Table Style Medium 9', start_row=0):
        if df.empty:
            ws.write(start_row, 0, "No hay datos disponibles.", self.fmt_na)
            return start_row + 2

        columns_meta = []
        for col in df.columns:
            fmt = None
            if _column_is_date(col):
                fmt = self.date_fmt
            elif _column_needs_decimal_format(col):
                fmt = self.num_fmt_2
            columns_meta.append({'header': col, 'format': fmt} if fmt else {'header': col})
        data = [
            [None if pd.isna(v) else v for v in row]
            for row in df.itertuples(index=False, name=None)
        ]
        last_row = start_row + len(df)
        last_col = len(df.columns) - 1
        ws.add_table(start_row, 0, last_row, last_col, {
            'data': data,
            'columns': columns_meta,
            'style': table_style,
            'banded_rows': True,
        })

        for col_idx, col in enumerate(df.columns):
            ws.set_column(col_idx, col_idx, _column_width(col))

        for col_idx, col in enumerate(df.columns):
            spec = CATEGORICAL_COLOR_MAPS.get(col)
            if not spec:
                continue
            is_bool_col = df[col].dropna().map(lambda v: isinstance(v, (bool, np.bool_))).all() if df[col].notna().any() else False
            for value, (bg, fg) in spec['colors'].items():
                cell_fmt = self.workbook.add_format({'bg_color': bg, 'font_color': fg, 'bold': True})
                if is_bool_col:
                    ws.conditional_format(start_row + 1, col_idx, last_row, col_idx, {
                        'type': 'cell', 'criteria': 'equal to',
                        'value': value.upper(), 'format': cell_fmt,
                    })
                elif spec['exact']:
                    ws.conditional_format(start_row + 1, col_idx, last_row, col_idx, {
                        'type': 'cell', 'criteria': 'equal to',
                        'value': f'"{value}"', 'format': cell_fmt,
                    })
                else:
                    ws.conditional_format(start_row + 1, col_idx, last_row, col_idx, {
                        'type': 'text', 'criteria': 'containing',
                        'value': value, 'format': cell_fmt,
                    })
        if 'Product_URL' in df.columns:
            url_col = list(df.columns).index('Product_URL')
            for i, val in enumerate(df['Product_URL']):
                if pd.notna(val) and str(val).startswith('http'):
                    ws.write_url(start_row + 1 + i, url_col, str(val), string="Link")

        ws.freeze_panes(start_row + 1, 1)
        return last_row + 2

    def _write_acquisition_windows(self, df):
        ws = self.workbook.add_worksheet('Acquisition_Windows')
        ws.set_tab_color('#1F4E78')
        if df.empty:
            ws.write(0, 0, "No se detectaron ventanas de adquisición.", self.title_fmt)
            return
        self._write_dataframe_table(ws, df)

    def _write_dashboard(self, df, input_params):
        ws = self.workbook.add_worksheet('Dashboard')
        ws.set_tab_color('#1F4E78')
        ws.hide_gridlines(2)
        ws.set_column(0, 0, 22)
        ws.set_column(1, 9, 12)

        row = 0
        ws.merge_range(row, 0, row, 9, "Dashboard de Factibilidad de Adquisición Multiespectral", self.title_fmt)
        ws.set_row(row, 28)
        row += 1
        aoi_line = (
            f"AOI: {input_params.get('AOI_Name', '-')}   |   "
            f"Lat: {input_params.get('AOI_Latitude_deg', '-')}°   "
            f"Lon: {input_params.get('AOI_Longitude_deg', '-')}°   |   "
            f"Radio: {input_params.get('AOI_Radius_km', '-')} km"
        )
        ws.merge_range(row, 0, row, 9, aoi_line, self.subtitle_fmt)
        row += 1

        start_p = input_params.get('Start_UTC')
        end_p = input_params.get('End_UTC')
        start_str = start_p.strftime('%Y-%m-%d %H:%M UTC') if hasattr(start_p, 'strftime') else str(start_p)
        end_str = end_p.strftime('%Y-%m-%d %H:%M UTC') if hasattr(end_p, 'strftime') else str(end_p)
        period_line = (
            f"Período evaluado: {start_str}  ->  {end_str}   |   "
            f"Satélites: {input_params.get('Satellites', '-')}"
        )
        ws.merge_range(row, 0, row, 9, period_line, self.info_fmt)
        row += 2

        if df.empty:
            ws.write(row, 0, "Estado: Sin ventanas de adquisición detectadas.", self.subtitle_fmt)
            return
        total = len(df)
        viable = len(df[df['Feasibility_Class'] == 'Viable'])
        cond = len(df[df['Feasibility_Class'] == 'Conditional'])
        not_v = len(df[df['Feasibility_Class'] == 'Not Viable'])

        kpi_cards = [
            ("VENTANAS TOTALES", str(total), '#1F4E78', 'white'),
            ("VIABLES", f"{viable} ({viable/total*100:.0f}%)", '#C6EFCE', '#006100'),
            ("CONDICIONALES", f"{cond} ({cond/total*100:.0f}%)", '#FFEB9C', '#9C6500'),
            ("NO VIABLES", f"{not_v} ({not_v/total*100:.0f}%)", '#FFC7CE', '#9C0006'),
        ]
        card_width = 2 
        kpi_row_start = row
        for i, (label, value, bg, fg) in enumerate(kpi_cards):
            c0 = i * (card_width + 1)
            c1 = c0 + card_width - 1
            label_fmt = self.workbook.add_format({**self.kpi_label_fmt_base, 'bg_color': bg, 'font_color': fg})
            value_fmt = self.workbook.add_format({**self.kpi_value_fmt_base, 'bg_color': bg, 'font_color': fg})
            ws.merge_range(kpi_row_start, c0, kpi_row_start, c1, label, label_fmt)
            ws.merge_range(kpi_row_start + 1, c0, kpi_row_start + 2, c1, value, value_fmt)
        row = kpi_row_start + 4

        extra_metrics = []
        df_viable = df[df['Feasibility_Class'] == 'Viable'].copy()
        if not df_viable.empty:
            next_opp = df_viable.loc[df_viable['Window_Start_UTC'].idxmin(), 'Window_Start_UTC']
            next_opp_str = next_opp.strftime('%Y-%m-%d %H:%M:%S') if hasattr(next_opp, 'strftime') else str(next_opp)
            extra_metrics.append(("Próxima Oportunidad Viable (UTC)", next_opp_str))

        if 'Satellite' in df.columns:
            top_sat = df['Satellite'].value_counts().idxmax()
            extra_metrics.append(("Satélite con Más Pasadas", f"{top_sat} ({df['Satellite'].value_counts().max()} pasos)"))

        if not_v > 0:
            reasons = df[df['Feasibility_Class'] == 'Not Viable']['Rejection_Reason'].value_counts()
            if not reasons.empty:
                extra_metrics.append(("Principal Causa de Rechazo", reasons.idxmax()))

        if 'Illumination_Limited_Opportunity' in df.columns:
            n_night_good = int((df['Illumination_Limited_Opportunity'] == True).sum())
            if n_night_good > 0:
                extra_metrics.append((
                    "⚠ Buena Geometría, Solo de Noche",
                    f"{n_night_good} pasada(s) — ver hoja 'Night_Opportunities'"
                ))

        for label, val in extra_metrics:
            ws.write(row, 0, label, self.subtitle_fmt)
            ws.merge_range(row, 1, row, 9, val, self.info_fmt)
            row += 1

        row += 1
        chart_data_row = row + 20
        ws.write(chart_data_row, 0, "Clase")
        ws.write(chart_data_row, 1, "Cantidad")
        pie_labels = ['Viable', 'Conditional', 'Not Viable']
        pie_values = [viable, cond, not_v]
        for i, (lbl, val) in enumerate(zip(pie_labels, pie_values)):
            ws.write(chart_data_row + i + 1, 0, lbl)
            ws.write(chart_data_row + i + 1, 1, val)

        chart_pie = self.workbook.add_chart({'type': 'pie'})
        chart_pie.add_series({
            'name': 'Clasificación de Factibilidad',
            'categories': ['Dashboard', chart_data_row + 1, 0, chart_data_row + len(pie_labels), 0],
            'values': ['Dashboard', chart_data_row + 1, 1, chart_data_row + len(pie_labels), 1],
            'points': [
                {'fill': {'color': '#C6EFCE'}},
                {'fill': {'color': '#FFEB9C'}},
                {'fill': {'color': '#FFC7CE'}}
            ],
            'data_labels': {'percentage': True, 'category': True, 'separator': '\n'}
        })
        chart_pie.set_title({'name': 'Distribución de Factibilidad'})
        ws.insert_chart(row, 0, chart_pie, {'x_scale': 1.2, 'y_scale': 1.2})

        if 'Satellite' in df.columns:
            sat_counts = df['Satellite'].value_counts().reset_index()
            sat_counts.columns = ['Satellite', 'Count']

            data_row = chart_data_row + len(pie_labels) + 3
            ws.write(data_row, 0, "Satellite")
            ws.write(data_row, 1, "Count")
            for i, r in sat_counts.iterrows():
                ws.write(data_row + i + 1, 0, r['Satellite'])
                ws.write(data_row + i + 1, 1, r['Count'])

            chart_bar = self.workbook.add_chart({'type': 'bar'})
            chart_bar.add_series({
                'name': 'Pasos por Satélite',
                'categories': ['Dashboard', data_row + 1, 0, data_row + len(sat_counts), 0],
                'values': ['Dashboard', data_row + 1, 1, data_row + len(sat_counts), 1],
                'fill': {'color': '#4F81BD'}
            })
            chart_bar.set_title({'name': 'Oportunidades por Satélite'})
            chart_bar.set_y_axis({'name': 'Satélite'})
            chart_bar.set_x_axis({'name': 'Número de Ventanas'})
            ws.insert_chart(row, 8, chart_bar, {'x_scale': 1.2, 'y_scale': 1.2})

    def _write_night_opportunities(self, df):
        ws = self.workbook.add_worksheet('Night_Opportunities')
        ws.set_tab_color('#1F4E78')

        if df.empty or 'Illumination_Limited_Opportunity' not in df.columns:
            ws.write(0, 0, "No hay datos disponibles.", self.fmt_na)
            return

        df_night = df[df['Illumination_Limited_Opportunity'] == True].copy()  # noqa: E712
        df_night = df_night.sort_values('Closest_Approach_UTC')

        ws.merge_range(0, 0, 0, 6,
            "Pasadas con excelente geometría orbital, bloqueadas solo por horario nocturno",
            self.title_fmt)
        ws.set_row(0, 24)

        cols = ['Window_ID', 'Satellite', 'Closest_Approach_UTC', 'Max_Elevation_deg',
                'Off_Nadir_Angle_deg', 'AOI_Coverage_percent', 'Geometric_Quality_Score',
                'Solar_Elevation_deg', 'Illumination_Status']
        cols = [c for c in cols if c in df_night.columns]

        if df_night.empty:
            ws.write(2, 0, "Ninguna pasada detectada en esta categoría para el período evaluado.", self.info_fmt)
            return

        self._write_dataframe_table(ws, df_night[cols], start_row=2)

    def _write_input_parameters(self, params):
        ws = self.workbook.add_worksheet('Input_Parameters')
        ws.write(0, 0, "Parámetro", self.header_fmt)
        ws.write(0, 1, "Valor", self.header_fmt)
        ws.set_column(0, 0, 30)
        ws.set_column(1, 1, 50)
        ws.freeze_panes(1, 0)

        row = 1
        for k, v in params.items():
            ws.write(row, 0, str(k))
            if isinstance(v, datetime):
                dt_clean = v.replace(tzinfo=None) if v.tzinfo is not None else v
                ws.write_datetime(row, 1, dt_clean, self.date_fmt)
            else:
                ws.write(row, 1, str(v))
            row += 1

    def _write_criteria(self, settings):
        ws = self.workbook.add_worksheet('Criteria')
        ws.write(0, 0, "Criterio", self.header_fmt)
        ws.write(0, 1, "Valor / Umbral", self.header_fmt)
        ws.set_column(0, 0, 40)
        ws.set_column(1, 1, 30)
        ws.freeze_panes(1, 0)

        row = 1

        def flatten_dict(d, parent_key=''):
            items = []
            for k, v in d.items():
                new_key = f"{parent_key}.{k}" if parent_key else k
                if isinstance(v, dict):
                    items.extend(flatten_dict(v, new_key).items())
                else:
                    items.append((new_key, v))
            return dict(items)

        flat_settings = flatten_dict(settings)
        for k, v in flat_settings.items():
            ws.write(row, 0, k)
            ws.write(row, 1, str(v))
            row += 1

    def _write_geometric_analysis(self, df):
        ws = self.workbook.add_worksheet('Geometric_Analysis')
        ws.set_tab_color('#4F81BD')
        geom_cols = [c for c in df.columns if any(x in c for x in ['Angle', 'Azimuth', 'Elevation', 'Distance', 'Coverage', 'Direction', 'Orbit'])]
        if not geom_cols: geom_cols = ['Window_ID', 'Feasibility_Class']

        df_geom = df[['Window_ID'] + geom_cols].copy()
        self._write_dataframe_table(ws, df_geom)

    def _write_radiometric_analysis(self, df):
        ws = self.workbook.add_worksheet('Radiometric_Analysis')
        ws.set_tab_color('#4F81BD')
        rad_cols = [c for c in df.columns if any(x in c for x in ['Solar', 'Glint', 'Illumination', 'Radiometric', 'Shadow', 'Saturation'])]
        if not rad_cols: rad_cols = ['Window_ID', 'Feasibility_Class']

        df_rad = df[['Window_ID'] + rad_cols].copy()
        self._write_dataframe_table(ws, df_rad)

    def _write_catalog_validation(self, df):
        ws = self.workbook.add_worksheet('Catalog_Validation')
        ws.set_tab_color('#808080')
        val_cols = [c for c in df.columns if any(x in c for x in ['Catalog', 'Product', 'Actual_', 'Error', 'Validation'])]
        if not val_cols: val_cols = ['Window_ID', 'Feasibility_Class']

        df_val = df[['Window_ID'] + val_cols].copy()
        next_row = self._write_dataframe_table(ws, df_val)
        ws.write(next_row, 0, "Nota: Los datos de validación requieren un CSV en data/input/catalog_validation.csv o conexión a API externa (V1).", self.fmt_na)

    def _write_satellite_sensors(self, sensor_configs):
        ws = self.workbook.add_worksheet('Satellite_Sensors')
        ws.set_tab_color('#808080')
        ws.write(0, 0, "Satélite / Sensor", self.header_fmt)
        ws.write(0, 1, "Parámetro", self.header_fmt)
        ws.write(0, 2, "Valor", self.header_fmt)
        ws.set_column(0, 0, 20)
        ws.set_column(1, 1, 30)
        ws.set_column(2, 2, 20)
        ws.freeze_panes(1, 0)

        row = 1
        for sat_key, sat_data in sensor_configs['sensors'].items():
            for param, val in sat_data.items():
                ws.write(row, 0, sat_key)
                ws.write(row, 1, param)
                ws.write(row, 2, str(val))
                row += 1

    def _write_methodology(self):
        ws = self.workbook.add_worksheet('Methodology')
        ws.set_tab_color('#808080')
        ws.set_column(0, 0, 100)

        metadata = [
            ("Framework Version", self.framework_version),
            ("Execution Date (UTC)", datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')),
            ("Python Version", sys.version.split()[0]),
            ("SGP4 Library Version", sgp4.__version__),
            ("Astropy Library Version", astropy.__version__),
            ("", ""),
            ("SISTEMAS DE COORDENADAS", ""),
            ("1. TEME", "Salida nativa de SGP4 (True Equator, Mean Equinox)."),
            ("2. ITRS / ECEF", "Sistema terrestre fijo. Transformación vía Astropy (IAU 2000/2006)."),
            ("3. WGS-84", "Elipsoide de referencia para Lat/Lon/Alt. Iteración de Bowring."),
            ("4. ENU", "Topocéntrico (East-North-Up) para Azimut/Elevación. Sin refracción atmosférica."),
            ("", ""),
            ("SUPUESTOS CIENTÍFICOS V1", ""),
            ("- Sun Glint", "Modelo geométrico de superficie lisa (especular). No incluye rugosidad (Cox-Munk)."),
            ("- Cobertura", "Huella rectangular aproximada. No modela distorsión cónica en bordes de barrido."),
            ("- Radiometría", "Evaluación puramente geométrica. No hay RTM (6S/MODTRAN) ni datos de nubes en V1."),
            ("- TLE", "Se asume validez < 7 días. SGP4 tiene error típico de 1-3 km para LEO."),
            ("- Off-Nadir", "Se usa el nadir geodésico (normal al elipsoide WGS-84) por defecto; "
                             "error de hasta ~0.19° si se usara el nadir geocéntrico en su lugar."),
        ]

        for i, (label, desc) in enumerate(metadata):
            if label in ["SISTEMAS DE COORDENADAS", "SUPUESTOS CIENTÍFICOS V1"]:
                ws.write(i, 0, label, self.subtitle_fmt)
            else:
                ws.write(i, 0, f"{label}: {desc}" if desc else label)
