import logging
import numpy as np
import pandas as pd
from .sensor_coverage import haversine_distance_km
logger = logging.getLogger(__name__)

def load_catalog_data(csv_path):
    try:
        df = pd.read_csv(csv_path, parse_dates=['Actual_Acquisition_UTC'])
        logger.info(f"Catálogo de validación cargado: {len(df)} productos.")
        return df
    except Exception as e:
        logger.error(f"Error al cargar el catálogo de validación: {e}")
        return pd.DataFrame()

def validate_predictions(df_predicted, df_catalog):
    if df_catalog.empty:
        logger.warning("No hay datos de catálogo para validar.")
        return df_predicted
    df_merged = df_predicted.merge(df_catalog, on='Window_ID', how='left', suffixes=('', '_Actual'))
    actual_time_utc = pd.to_datetime(df_merged['Actual_Acquisition_UTC'], utc=True, errors='coerce')
    predicted_time_utc = pd.to_datetime(df_merged['Closest_Approach_UTC'], utc=True, errors='coerce')

    time_mask = actual_time_utc.notna() & predicted_time_utc.notna()
    df_merged.loc[time_mask, 'Time_Error_seconds'] = (
        actual_time_utc[time_mask] - predicted_time_utc[time_mask]
    ).dt.total_seconds().abs()

    spatial_mask = df_merged['Actual_Lat_deg'].notna() & df_merged['Actual_Lon_deg'].notna()
    spatial_errors = []
    for _, row in df_merged[spatial_mask].iterrows():
        dist = haversine_distance_km(
            row['Satellite_Latitude_deg'], row['Satellite_Longitude_deg'],
            row['Actual_Lat_deg'], row['Actual_Lon_deg']
        )
        spatial_errors.append(dist)
    df_merged.loc[spatial_mask, 'Position_Error_km'] = spatial_errors
    df_merged['Predicted_Positive'] = df_merged['Feasibility_Class'].isin(['Viable', 'Conditional'])
    df_merged['Actual_Positive'] = df_merged['Cloud_Cover_Percent'].notna() & (df_merged['Cloud_Cover_Percent'] < 50.0)

    tp = ((df_merged['Predicted_Positive'] == True) & (df_merged['Actual_Positive'] == True)).sum()
    tn = ((df_merged['Predicted_Positive'] == False) & (df_merged['Actual_Positive'] == False)).sum()
    fp = ((df_merged['Predicted_Positive'] == True) & (df_merged['Actual_Positive'] == False)).sum()
    fn = ((df_merged['Predicted_Positive'] == False) & (df_merged['Actual_Positive'] == True)).sum()

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

    logger.info(f"Validación completada. TP: {tp}, TN: {tn}, FP: {fp}, FN: {fn}")
    logger.info(f"Precisión: {precision:.2f}, Recall: {recall:.2f}, F1-Score: {f1:.2f}")

    df_merged['Validation_Status'] = np.where(df_merged['Actual_Acquisition_UTC'].notna(), 'Validated', 'Pending')
    df_merged['Catalog_Checked'] = True

    return df_merged
