import logging
import astropy.units as u
import numpy as np
from astropy.coordinates import ITRS, TEME, CartesianRepresentation
from astropy.time import Time

logger = logging.getLogger(__name__)

# Constantes WGS-84
WGS84_A = 6378.137         
WGS84_F = 1 / 298.257223563 
WGS84_E2 = 2 * WGS84_F - WGS84_F**2 

def teme_to_itrs(pos_teme_km, time_utc):
    t = Time(time_utc)
    rep = CartesianRepresentation(
        pos_teme_km[0]*u.km, pos_teme_km[1]*u.km, pos_teme_km[2]*u.km
    )
    teme_frame = TEME(rep, obstime=t)
    itrs_frame = teme_frame.transform_to(ITRS(obstime=t))
    return itrs_frame.cartesian.xyz.to(u.km).value

def teme_to_itrs_batch(pos_teme_km_array, times_utc):
    pos_teme_km_array = np.asarray(pos_teme_km_array)
    t = Time(list(times_utc))
    rep = CartesianRepresentation(
        pos_teme_km_array[:, 0] * u.km,
        pos_teme_km_array[:, 1] * u.km,
        pos_teme_km_array[:, 2] * u.km
    )
    teme_frame = TEME(rep, obstime=t)
    itrs_frame = teme_frame.transform_to(ITRS(obstime=t))
    xyz = itrs_frame.cartesian.xyz.to(u.km).value  # shape (3, N)
    return xyz.T  # shape (N, 3)

def itrs_to_geodetic_wgs84(pos_itrs_km):
    x, y, z = pos_itrs_km
    lon = np.arctan2(y, x)

    p = np.sqrt(x**2 + y**2)
    lat = np.arctan2(z, p * (1 - WGS84_E2)) # Initial guess

    # Iteración para convergencia (típicamente 2-3 iteraciones)
    for _ in range(5):
        N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
        lat_new = np.arctan2(z + WGS84_E2 * N * np.sin(lat), p)
        if np.allclose(lat, lat_new, atol=1e-12):
            break
        lat = lat_new

    N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    alt = (p / np.cos(lat)) - N

    return np.degrees(lat), np.degrees(lon), alt

def itrs_to_geodetic_wgs84_batch(pos_itrs_km_array):
    pos = np.atleast_2d(pos_itrs_km_array)
    x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
    lon = np.arctan2(y, x)

    p = np.sqrt(x**2 + y**2)
    lat = np.arctan2(z, p * (1 - WGS84_E2))

    for _ in range(5):
        N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
        lat = np.arctan2(z + WGS84_E2 * N * np.sin(lat), p)

    N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    alt = (p / np.cos(lat)) - N

    return np.degrees(lat), np.degrees(lon), alt


def ecef_to_topocentric_enu(sat_ecef_km, aoi_lat_deg, aoi_lon_deg, aoi_alt_km=0.0):
    lat = np.radians(aoi_lat_deg)
    lon = np.radians(aoi_lon_deg)

    N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    aoi_ecef = np.array([
        (N + aoi_alt_km) * np.cos(lat) * np.cos(lon),
        (N + aoi_alt_km) * np.cos(lat) * np.sin(lon),
        (N * (1 - WGS84_E2) + aoi_alt_km) * np.sin(lat)
    ])

    rho_ecef = sat_ecef_km - aoi_ecef
    range_km = np.linalg.norm(rho_ecef)

    if range_km == 0:
        return 0.0, 90.0, 0.0

    R = np.array([
        [-np.sin(lon), np.cos(lon), 0],
        [-np.sin(lat)*np.cos(lon), -np.sin(lat)*np.sin(lon), np.cos(lat)],
        [np.cos(lat)*np.cos(lon), np.cos(lat)*np.sin(lon), np.sin(lat)]
    ])

    rho_enu = R @ rho_ecef
    e, n, u_comp = rho_enu
    az_rad = np.arctan2(e, n)
    az_deg = np.degrees(az_rad) % 360.0
    el_rad = np.arctan2(u_comp, np.sqrt(e**2 + n**2)) #Elevación
    el_deg = np.degrees(el_rad)

    return az_deg, el_deg, range_km

def ecef_to_topocentric_enu_batch(sat_ecef_km_array, aoi_lat_deg, aoi_lon_deg, aoi_alt_km=0.0):
    lat = np.radians(aoi_lat_deg)
    lon = np.radians(aoi_lon_deg)

    N = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    aoi_ecef = np.array([
        (N + aoi_alt_km) * np.cos(lat) * np.cos(lon),
        (N + aoi_alt_km) * np.cos(lat) * np.sin(lon),
        (N * (1 - WGS84_E2) + aoi_alt_km) * np.sin(lat)
    ])

    rho_ecef = sat_ecef_km_array - aoi_ecef
    range_km = np.linalg.norm(rho_ecef, axis=1)
    R = np.array([
        [-np.sin(lon), np.cos(lon), 0],
        [-np.sin(lat)*np.cos(lon), -np.sin(lat)*np.sin(lon), np.cos(lat)],
        [np.cos(lat)*np.cos(lon), np.cos(lat)*np.sin(lon), np.sin(lat)]
    ])
    rho_enu = rho_ecef @ R.T 
    e, n, u_comp = rho_enu[:, 0], rho_enu[:, 1], rho_enu[:, 2]
    az_deg = np.degrees(np.arctan2(e, n)) % 360.0
    el_deg = np.degrees(np.arctan2(u_comp, np.sqrt(e**2 + n**2)))

    return az_deg, el_deg, range_km
