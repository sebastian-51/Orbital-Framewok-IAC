import logging
import os
import requests
logger = logging.getLogger(__name__)

# Mapeo oficial de Satélites a sus NORAD IDs
SATELLITE_NORAD = {
    "LANDSAT 8": 39084,
    "LANDSAT 9": 49260,
    "SENTINEL 2A": 40697,
    "SENTINEL 2B": 42063,
    "TERRA": 25994,  # MODIS: swath 2330 km, revisita casi diaria (1-2 días)
    "AQUA": 27424,   # MODIS gemelo de Terra, órbita ascendente (~13:30 vs 10:30 de Terra)
}

SPACETRACK_LOGIN_URL = "https://www.space-track.org/ajaxauth/login"
SPACETRACK_QUERY_URL = (
    "https://www.space-track.org/basicspacedata/query/class/gp/"
    "NORAD_CAT_ID/{norad_id}/orderby/EPOCH%20desc/limit/1/format/tle"
)


def download_tle_from_celestrak(satellite_name="LANDSAT 8"):
    """
    Descarga el TLE REAL desde CelesTrak usando el NORAD ID específico.
    """
    norad_id = SATELLITE_NORAD.get(satellite_name.upper())
    if not norad_id:
        logger.error(f"NORAD ID no encontrado para {satellite_name}")
        return None, None

    url = f"https://celestrak.org/NORAD/elements/gp.php?CATNR={norad_id}&FORMAT=tle"

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/plain',
    }

    try:
        logger.info(f"📡 Solicitando TLE REAL a CelesTrak para {satellite_name} (NORAD {norad_id})...")
        response = requests.get(url, headers=headers, proxies={'http': None, 'https': None}, timeout=15)
        response.raise_for_status() 

        lines = response.text.strip().split('\n')
        if len(lines) >= 3:
            line1 = lines[1].strip()
            line2 = lines[2].strip()
            logger.info("✅ TLE REAL descargado exitosamente.")
            return line1, line2
        else:
            logger.error(f"❌ Respuesta de CelesTrak inválida para {satellite_name}.")
            return None, None

    except requests.exceptions.HTTPError as e:
        logger.error(f" CelesTrak rechazó la solicitud ({e}). No se usarán datos falsos.")
        return None, None
    except Exception as e: 
        logger.error(f"🚫 Error de red al obtener datos reales: {e}")
        return None, None


def download_tle_from_spacetrack(satellite_name="LANDSAT 8"):
    """
   Space-Track requiere una cuenta gratuita en https://www.space-track.org/ y las
    credenciales configuradas como VARIABLES DE ENTORNO.

        SPACETRACK_USER       (tu usuario/email de Space-Track)
        SPACETRACK_PASSWORD   (tu contraseña de Space-Track)

    En Windows (cmd), antes de correr main.py:
        set SPACETRACK_USER=tu_usuario
        set SPACETRACK_PASSWORD=tu_contraseña
    """
    norad_id = SATELLITE_NORAD.get(satellite_name.upper())
    if not norad_id:
        logger.error(f"NORAD ID no encontrado para {satellite_name}")
        return None, None

    username = os.environ.get("SPACETRACK_USER")
    password = os.environ.get("SPACETRACK_PASSWORD")
    if not username or not password:
        logger.debug(
            "Credenciales de Space-Track no configuradas "
            "(variables de entorno SPACETRACK_USER / SPACETRACK_PASSWORD); "
            "se omite esta fuente."
        )
        return None, None

    try:
        session = requests.Session()
        login_resp = session.post(
            SPACETRACK_LOGIN_URL,
            data={"identity": username, "password": password},
            timeout=15,
        )
        login_resp.raise_for_status()

        query_url = SPACETRACK_QUERY_URL.format(norad_id=norad_id)
        logger.info(f"📡 Solicitando TLE a Space-Track.org para {satellite_name} (NORAD {norad_id})...")
        tle_resp = session.get(query_url, timeout=15)
        tle_resp.raise_for_status()

        lines = [line for line in tle_resp.text.strip().split('\n') if line.strip()]
        if len(lines) >= 2:
            line1, line2 = lines[0].strip(), lines[1].strip()
            logger.info("✅ TLE descargado exitosamente desde Space-Track.org.")
            return line1, line2
        else:
            logger.error(f"❌ Respuesta de Space-Track.org inválida o vacía para {satellite_name}.")
            return None, None

    except requests.exceptions.HTTPError as e:
        logger.error(f"Space-Track.org rechazó la solicitud ({e}). Verifica tu usuario/contraseña.")
        return None, None
    except Exception as e:  
        logger.error(f"🚫 Error de red al obtener TLE de Space-Track.org: {e}")
        return None, None

def load_tle_from_local_catalog(satellite_name, file_path):
    if not os.path.exists(file_path):
        logger.debug(f"Catálogo TLE local no encontrado: {file_path}")
        return None, None

    target = satellite_name.strip().upper()

    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = [ln.rstrip('\r\n') for ln in f.readlines()]
    except Exception as e:  # noqa: BLE001
        logger.error(f"Error leyendo el catálogo TLE local {file_path}: {e}")
        return None, None

    i = 0
    while i < len(lines) - 2:
        name_line = lines[i].strip()
        if name_line.startswith('0 '):
            name = name_line[2:].strip().upper()
            line1 = lines[i + 1].strip()
            line2 = lines[i + 2].strip()
            if name == target and line1.startswith('1 ') and line2.startswith('2 '):
                logger.info(f"✅ TLE de {satellite_name} encontrado en catálogo local ({file_path}).")
                return line1, line2
            i += 3
        else:
            i += 1

    logger.error(f"No se encontró '{satellite_name}' en el catálogo local {file_path}.")
    return None, None
