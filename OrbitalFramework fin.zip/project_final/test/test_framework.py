import os
import sys
from datetime import datetime, timezone

import numpy as np

# Añadir la raíz del proyecto al path para importar el paquete src
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.scoring import calculate_feasibility_scores
from src.solar_geometry import calculate_solar_geometry
from src.tle_loader import parse_tle_epoch, validate_tle_checksum


class TestTLEValidation:
    def test_valid_checksum(self):
        # TLE de ejemplo con checksum válido
        line1 = "1 39084U 13008A   23001.50000000  .00000500  00000-0  25000-4 0  9993"
        assert validate_tle_checksum(line1) is True

    def test_invalid_checksum(self):
        line1 = "1 39084U 13008A   23001.50000000  .00000500  00000-0  25000-4 0  9999" # Último dígito alterado
        assert validate_tle_checksum(line1) is False

    def test_parse_epoch(self):
        line1 = "1 39084U 13008A   23001.50000000  .00000500  00000-0  25000-4 0  9995"
        epoch = parse_tle_epoch(line1)
        assert epoch.year == 2023
        assert epoch.month == 1
        assert epoch.day == 1


class TestSolarGeometry:
    def test_sza_elevation_consistency(self):
        # Verifica que SZA + Elevación = 90 en cualquier punto y tiempo
        time_utc = datetime(2023, 6, 21, 12, 0, 0, tzinfo=timezone.utc)
        aoi_lat, aoi_lon = 40.4168, -3.7038 # Madrid

        result = calculate_solar_geometry(time_utc, aoi_lat, aoi_lon, sensor_azimuth_deg=180.0)

        sza = result['solar_zenith_angle_deg']
        elev = result['solar_elevation_deg']

        assert np.isclose(sza + elev, 90.0, atol=1e-6), f"SZA ({sza}) + Elev ({elev}) != 90"


class TestScoring:
    def test_perfect_score(self):
        window_data = {
            # RENOMBRADO: antes 'Max_Coverage_percent'. acquisition_windows.py
            # y scoring.py ahora usan 'AOI_Coverage_percent' consistentemente
            # (alineado con REQUIRED_COLUMNS de excel_exporter.py).
            'AOI_Coverage_percent': 100.0,
            'Solar_Zenith_Angle_deg': 10.0,
            'Off_Nadir_Angle_deg': 0.0,
            'Sun_Glint_Risk': 'Low',
            'TLE_Age_days': 1.0,
            'Solar_Elevation_deg': 80.0,
            'Illumination_Status': 'Daylight'
        }
        sensor_config = {'max_off_nadir_angle_deg': 15.0, 'is_passive_optical': True}
        settings = {
            'geometry_criteria': {'min_aoi_coverage_percent': 80.0, 'max_solar_zenith_angle_deg': 70.0, 'min_solar_elevation_deg': 20.0, 'max_tle_age_days': 7.0},
            'scoring_weights': {'coverage': 30, 'solar_geometry': 25, 'viewing_angle': 15, 'sun_glint': 15, 'tle_freshness': 15},
            'feasibility_classes': {'viable_min_score': 80.0, 'conditional_min_score': 60.0},
            'critical_rejection_criteria': [
                'aoi_out_of_swath', 'solar_elevation_below_minimum',
                'off_nadir_exceeds_sensor_limit', 'nighttime_for_passive_optical',
            ],
        }

        result = calculate_feasibility_scores(window_data, sensor_config, settings)

        # CORREGIDO: con TLE_Age_days=1.0 sobre un máximo de 7 días,
        # TLE_Score = 100*(7-1)/7 = 85.71, y Geometry_Score (SZA=10°,
        # max=70°) = 100*(70-10)/70 = 85.71. El promedio ponderado correcto
        # con estos pesos (30/25/15/15/15) da 94.29, no 100.0. El test
        # anterior esperaba 100.0 porque scoring.py tenía un bug de
        # normalización (dividía por total_weight/100 en vez de por
        # total_weight) que saturaba casi cualquier combinación de scores en
        # 100 tras el clip — es decir, el test validaba el bug, no el
        # comportamiento correcto.
        assert np.isclose(result['Overall_Score'], 94.29, atol=0.01)
        assert result['Feasibility_Class'] == 'Viable'

    def test_overall_score_reflects_individual_scores(self):
        """
        Prueba de regresión específica para el bug de normalización: dos
        ventanas con calidad claramente distinta deben producir Overall_Score
        claramente distintos (antes del fix, ambas casi siempre daban 100.0).
        """
        sensor_config = {'max_off_nadir_angle_deg': 15.0, 'is_passive_optical': True}
        settings = {
            'geometry_criteria': {'min_aoi_coverage_percent': 50.0, 'max_solar_zenith_angle_deg': 70.0, 'min_solar_elevation_deg': 20.0, 'max_tle_age_days': 7.0},
            'scoring_weights': {'coverage': 25, 'solar_geometry': 25, 'viewing_angle': 20, 'sun_glint': 20, 'tle_freshness': 10},
            'feasibility_classes': {'viable_min_score': 75.0, 'conditional_min_score': 50.0},
            'critical_rejection_criteria': [
                'aoi_out_of_swath', 'solar_elevation_below_minimum',
                'off_nadir_exceeds_sensor_limit', 'nighttime_for_passive_optical',
            ],
        }

        good_window = {
            'AOI_Coverage_percent': 85.0, 'Solar_Zenith_Angle_deg': 30.0,
            'Solar_Elevation_deg': 60.0, 'Off_Nadir_Angle_deg': 5.0,
            'Sun_Glint_Risk': 'Low', 'TLE_Age_days': 1.5,
            'Illumination_Status': 'Daylight',
        }
        bad_window = {
            'AOI_Coverage_percent': 85.0, 'Solar_Zenith_Angle_deg': 68.0,
            'Solar_Elevation_deg': 22.0, 'Off_Nadir_Angle_deg': 14.0,
            'Sun_Glint_Risk': 'High', 'TLE_Age_days': 1.5,
            'Illumination_Status': 'Daylight',
        }

        good_result = calculate_feasibility_scores(good_window, sensor_config, settings)
        bad_result = calculate_feasibility_scores(bad_window, sensor_config, settings)

        assert good_result['Overall_Score'] > bad_result['Overall_Score']
        assert good_result['Overall_Score'] < 100.0  # no debe saturar en 100

    def test_critical_rejection_nighttime(self):
        window_data = {
            'AOI_Coverage_percent': 100.0,
            'Solar_Zenith_Angle_deg': 150.0, # Noche
            'Off_Nadir_Angle_deg': 0.0,
            'Sun_Glint_Risk': 'Low',
            'TLE_Age_days': 1.0,
            'Solar_Elevation_deg': -60.0,
            'Illumination_Status': 'Night'
        }
        sensor_config = {'max_off_nadir_angle_deg': 15.0, 'is_passive_optical': True}
        settings = {
            'geometry_criteria': {'min_aoi_coverage_percent': 80.0, 'max_solar_zenith_angle_deg': 70.0, 'min_solar_elevation_deg': 20.0, 'max_tle_age_days': 7.0},
            'scoring_weights': {'coverage': 30, 'solar_geometry': 25, 'viewing_angle': 15, 'sun_glint': 15, 'tle_freshness': 15},
            'feasibility_classes': {'viable_min_score': 80.0, 'conditional_min_score': 60.0},
            'critical_rejection_criteria': ['nighttime_for_passive_optical']
        }

        result = calculate_feasibility_scores(window_data, sensor_config, settings)
        assert result['Feasibility_Class'] == 'Not Viable'
        assert 'nighttime_for_passive_optical' in result['Rejection_Reason']

    def test_critical_criteria_list_is_now_functional(self):
        """
        Prueba de regresión: scoring.py ahora SÍ lee critical_rejection_criteria.
        Si un criterio que se cumple NO está en la lista, ya no debe forzar el
        rechazo automático (aunque sí puede seguir bajando el Overall_Score).
        """
        window_data = {
            'AOI_Coverage_percent': 100.0,
            'Solar_Zenith_Angle_deg': 150.0,  # Noche
            'Off_Nadir_Angle_deg': 0.0,
            'Sun_Glint_Risk': 'Low',
            'TLE_Age_days': 1.0,
            'Solar_Elevation_deg': -60.0,
            'Illumination_Status': 'Night'
        }
        sensor_config = {'max_off_nadir_angle_deg': 15.0, 'is_passive_optical': True}
        settings = {
            'geometry_criteria': {'min_aoi_coverage_percent': 80.0, 'max_solar_zenith_angle_deg': 70.0, 'min_solar_elevation_deg': 20.0, 'max_tle_age_days': 7.0},
            'scoring_weights': {'coverage': 30, 'solar_geometry': 25, 'viewing_angle': 15, 'sun_glint': 15, 'tle_freshness': 15},
            'feasibility_classes': {'viable_min_score': 80.0, 'conditional_min_score': 60.0},
            # Deliberadamente vacía: ningún criterio fuerza rechazo automático.
            'critical_rejection_criteria': [],
        }

        result = calculate_feasibility_scores(window_data, sensor_config, settings)
        # Con SZA=150 el Geometry_Score es 0, así que igual será "Not Viable"
        # por score bajo, pero la razón ya NO debe ser un rechazo "Critical".
        assert not result['Rejection_Reason'].startswith('Critical')
