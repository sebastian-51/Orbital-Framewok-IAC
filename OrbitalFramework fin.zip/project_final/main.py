import logging
import os
import sys
import time
from datetime import datetime, timedelta, timezone
import numpy as np
import pandas as pd
os.makedirs('data/output', exist_ok=True)
os.makedirs('data/input', exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("data/output/framework_execution.log", encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

#Importacuon de módulos del framework
from src.acquisition_windows import detect_acquisition_windows
from src.catalog_validation import load_catalog_data, validate_predictions
from src.config_manager import get_sensors, get_settings
from src.excel_exporter import ExcelExporter
from src.glint_analysis import (
    calculate_glint_angle_and_risk,
    get_sensor_unit_vector_from_aoi,
)
from src.orbit_propagator import propagate_orbit
from src.radiometric_feasibility import evaluate_radiometric_feasibility
from src.scoring import calculate_feasibility_scores
from src.solar_geometry import calculate_solar_geometry, get_sun_vector_enu
from src.tle_downloader import (
    download_tle_from_celestrak,
    download_tle_from_spacetrack,
    load_tle_from_local_catalog,
)
from src.tle_loader import load_and_validate_tle

TLE_DOWNLOAD_DELAY_SECONDS = 1.5 # Debido al proceso de varios satélites en la misma ejecución.
CATALOG_VALIDATION_CSV_PATH = os.path.join('data', 'input', 'catalog_validation.csv') #Nuestro catálogo de validación (SE CARGA MANUALMENTE)
TLE_LOCAL_CATALOG_PATH = os.path.join('data', 'input', 'tle_catalog_3le.txt') #Catálogo completo 3LE, como 3ra fuente de respaldo.


def _enrich_window(window, aoi_config, sensor_config, settings, tle_age):
    t_closest = window['Closest_Approach_UTC']
    az_sensor = window['Azimuth_deg']
    off_nadir_deg = window['Off_Nadir_Angle_deg']

    #Geometría solar
    sol_geom = calculate_solar_geometry(t_closest, aoi_config['lat'], aoi_config['lon'], az_sensor)
    sensor_vec = get_sensor_unit_vector_from_aoi(az_sensor, window['Max_Elevation_deg'])
    sun_unit_enu = get_sun_vector_enu(t_closest, aoi_config['lat'], aoi_config['lon'])

    glint_angle, glint_risk = calculate_glint_angle_and_risk(
        sun_unit_enu, sensor_vec, settings['glint_analysis']
    )

    #Factibilidad radiométrica
    rad_eval = evaluate_radiometric_feasibility(
        sol_geom['solar_elevation_deg'],
        sol_geom['illumination_status'],
        glint_risk
    )

    #Ángulo de fase (Sol-Objetivo-Sensor)Ley esf. de cos.
    sza_rad = np.radians(sol_geom['solar_zenith_angle_deg'])
    vza_rad = np.radians(off_nadir_deg)
    rel_az_rad = np.radians(sol_geom['relative_azimuth_deg'])
    cos_phase = (
        np.cos(sza_rad) * np.cos(vza_rad)
        + np.sin(sza_rad) * np.sin(vza_rad) * np.cos(rel_az_rad)
    )
    phase_angle_deg = np.degrees(np.arccos(np.clip(cos_phase, -1.0, 1.0)))

    #Consolidar todo en un único diccionario con nombres para Excel
    w_data = window.to_dict()
    w_data['Solar_Zenith_Angle_deg'] = sol_geom['solar_zenith_angle_deg']
    w_data['Solar_Elevation_deg'] = sol_geom['solar_elevation_deg']
    w_data['Solar_Azimuth_deg'] = sol_geom['solar_azimuth_deg']
    w_data['Relative_Azimuth_deg'] = sol_geom['relative_azimuth_deg']
    w_data['Illumination_Status'] = sol_geom['illumination_status']
    w_data['Phase_Angle_deg'] = phase_angle_deg

    w_data['Glint_Angle_deg'] = glint_angle
    w_data['Sun_Glint_Risk'] = glint_risk

    w_data['Radiometric_Status'] = rad_eval.get('radiometric_status', 'Unknown')
    w_data['Shadow_Risk'] = rad_eval.get('shadow_risk', 'Not evaluated')
    w_data['Saturation_Risk'] = rad_eval.get('saturation_risk', 'Not evaluated')
    w_data['Cloud_Status'] = rad_eval.get('cloud_status', 'Not evaluated')

    w_data['TLE_Age_days'] = tle_age

    #Scoring y clasificación
    score_res = calculate_feasibility_scores(w_data, sensor_config, settings)
    w_data.update(score_res)

    return w_data


def process_satellite(satellite_name, sensor_key, sensor_config, aoi_config,
                      start_utc, end_utc, step_seconds, settings):
    """
    Solo procesa un solo satélite, descarga TLE real, propaga, detecta ventanas
    y enriquece con geometría solar, glint, radiometría y scoring.
    """
    logger.info(f"\n{'='*60}")
    logger.info(f"PROCESANDO: {satellite_name}")
    logger.info(f"{'='*60}")
    time.sleep(1)

    # Descargar TLE por medio de CelesTrak
    # TLE secundario Space-Track.org (respaldo, requiere SPACETRACK_USER/SPACETRACK_PASSWORD)**Leer eL README.md 
    # Último respaldo catálogo 3LE local
    tle_line1, tle_line2 = download_tle_from_celestrak(satellite_name)

    if tle_line1 is None or tle_line2 is None:
        logger.warning(f"CelesTrak no disponible para {satellite_name}; probando Space-Track.org como respaldo...")
        tle_line1, tle_line2 = download_tle_from_spacetrack(satellite_name)
        time.sleep(1) 

    if tle_line1 is None or tle_line2 is None:
        logger.warning(f"Space-Track.org tampoco disponible para {satellite_name}; probando catálogo local...")
        tle_line1, tle_line2 = load_tle_from_local_catalog(satellite_name, TLE_LOCAL_CATALOG_PATH)
        time.sleep(1)

    if tle_line1 is None or tle_line2 is None:
        logger.error(f"❌ No se pudo obtener TLE para {satellite_name} desde ningún recurso.")
        time.sleep(0.5)
        logger.error("Por favor espere. . . ")
        time.sleep(0.5)
        return None

    # Validadndo TLE
    try:
        tle_data, tle_age = load_and_validate_tle(tle_line1, tle_line2, start_utc)
        logger.info(f"TLE válido. Época: {tle_data.epoch_utc.strftime('%Y-%m-%d %H:%M:%S')} UTC. Antigüedad: {tle_age:.1f} días")
    except Exception as e: 
        logger.error(f"Error validando TLE de {satellite_name}: {e}")
        time.sleep(0.5)
        return None

    df_prop = propagate_orbit(tle_data, start_utc, end_utc, step_seconds,
                              aoi_config['lat'], aoi_config['lon'])

    if df_prop.empty:
        logger.warning(f"No se logro generar datos de propagación para {satellite_name}.")
        time.sleep(0.5)
        return None

    df_windows = detect_acquisition_windows(df_prop, sensor_config, aoi_config, step_seconds=step_seconds)

    if df_windows.empty:
        logger.warning(f"⚠️  NO SE DETECTARON VENTANAS para {satellite_name} en este período.")
        time.sleep(0.5)
        return None

    logger.info(f"✓ Se detectaron {len(df_windows)} ventanas para {satellite_name}")
    logger.info("Enriqueciendo datos por favor espere un momento...")
    time.sleep(1)

    enriched_rows = []
    for _, window in df_windows.iterrows():
        try:
            w_data = _enrich_window(window, aoi_config, sensor_config, settings, tle_age)
            enriched_rows.append(w_data)
        except Exception as e: 
            logger.error(
                f"Error enriqueciendo la ventana {window.get('Window_ID', '?')} "
                f"de {satellite_name}: {e}. Se omite esta ventana."
            )
            time.sleep(0.5)
            continue

    if not enriched_rows:
        logger.warning(f"Ninguna ventana pudo enriquecerse correctamente para {satellite_name}.")
        time.sleep(0.5)
        return None

    df_final = pd.DataFrame(enriched_rows)
    satellite_slug = satellite_name.replace(' ', '_')
    df_final['Window_ID'] = df_final['Window_ID'].apply(lambda w: f"{satellite_slug}_{w}")
    df_final['Run_ID'] = f"RUN_{datetime.now(timezone.utc).strftime('%Y%m%d')}_{satellite_slug}"
    df_final['Satellite'] = satellite_name
    df_final['Sensor'] = sensor_config['sensor']
    df_final['NORAD_ID'] = tle_data.norad_id
    df_final['AOI_Name'] = aoi_config['name']
    df_final['AOI_Latitude_deg'] = aoi_config['lat']
    df_final['AOI_Longitude_deg'] = aoi_config['lon']
    df_final['TLE_Epoch_UTC'] = tle_data.epoch_utc
    df_final['Spatial_Resolution_m'] = sensor_config['spatial_resolution_m']
    df_final['Swath_Width_km'] = sensor_config['swath_width_km']
    time.sleep(0.5)

    return df_final


def run_framework_multi_satellite():
    logger.info("="*70)
    logger.info("ORBITAL PREDICTIVE FRAMEWORK V3.0 - EVALUACIÓN MULTI-SATÉLITE")
    logger.info("="*70)
    time.sleep(1)

    settings = get_settings()
    sensors = get_sensors()


    aoi_config = {
        'name': 'Madrid_Centro',
        'lat': 40.4168,
        'lon': -3.7038,
        'radius_km': 15.0
    }
    logger.info(f"AOI: {aoi_config['name']} (Lat: {aoi_config['lat']}°, Lon: {aoi_config['lon']}°, Radio: {aoi_config['radius_km']} km)")

    #Usamos un periodo de evaluación de 3 días para tener buena confiabilidad del SGP4
    #Recordemos que TLE válido < 7 días.
    now = datetime.now(timezone.utc)
    start_utc = now - timedelta(days=1)
    end_utc = now + timedelta(days=2)
    step_seconds = 10  # Paso temporal de 10 segundos

    satellites_to_process = [
        ('landsat_8_oli', 'LANDSAT 8'),
        ('landsat_9_oli2', 'LANDSAT 9'),
        ('sentinel_2a_msi', 'SENTINEL 2A'),
        ('sentinel_2b_msi', 'SENTINEL 2B'),
        ('terra_modis', 'TERRA'), 
        ('aqua_modis', 'AQUA'),
    ]

    all_windows = []

    for i, (sensor_key, sat_name) in enumerate(satellites_to_process):
        if sensor_key not in sensors['sensors']:
            logger.warning(f"Sensor {sensor_key} no configurado en sensors.yaml. Saltando...")
            time.sleep(0.5)
            continue

        sensor_config = sensors['sensors'][sensor_key]

        df_res = process_satellite(
            sat_name, sensor_key, sensor_config, aoi_config,
            start_utc, end_utc, step_seconds, settings
        )

        if df_res is not None and not df_res.empty:
            all_windows.append(df_res)

        if i < len(satellites_to_process) - 1:
            time.sleep(TLE_DOWNLOAD_DELAY_SECONDS)

    if not all_windows:
        logger.warning("\n" + "="*70)
        logger.warning("NO SE DETECTARON VENTANAS DE ADQUISICIÓN PARA NINGÚN SATÉLITE")
        logger.warning("\n" + "="*70)
        time.sleep(1)
        logger.warning(f"Período evaluado: {start_utc.strftime('%Y-%m-%d')} a {end_utc.strftime('%Y-%m-%d')}")
        time.sleep(0.5)
        logger.warning(f"AOI: {aoi_config['name']} (Lat: {aoi_config['lat']}°, Lon: {aoi_config['lon']}°)")
        time.sleep(0.5)
        logger.warning("\nPosibles causas:")
        logger.warning("  1. Los satélites no pasan sobre la AOI en este período de evaluación")
        logger.warning("  2. Los ciclos de revisita no coinciden con estas fechas")
        logger.warning("  3. Fallo en la descarga de TLEs reales desde CelesTrak")
        time.sleep(1)
        logger.warning("\nRecomendación: Amplía el período de evaluación o verifica tu conexión a internet.")
        time.sleep(0.5)

        df_final = pd.DataFrame()
    else:
        df_final = pd.concat(all_windows, ignore_index=True)
        logger.info(f"\n{'='*70}")
        logger.info(f"TOTAL DE VENTANAS DETECTADAS: {len(df_final)}")
        logger.info(f"{'='*70}")
        time.sleep(1)

        # Resumen satélite
        for sat in df_final['Satellite'].unique():
            count = len(df_final[df_final['Satellite'] == sat])
            logger.info(f"  {sat}: {count} ventanas")
            time.sleep(0.5)

        # Validación contra catálogo real
        if os.path.exists(CATALOG_VALIDATION_CSV_PATH):
            logger.info(f"Catálogo de validación encontrado en {CATALOG_VALIDATION_CSV_PATH}. Ejecutando validación...")
            df_catalog = load_catalog_data(CATALOG_VALIDATION_CSV_PATH)
            df_final = validate_predictions(df_final, df_catalog)
            time.sleep(1)
        else:
            logger.info(
                f"No se encontró {CATALOG_VALIDATION_CSV_PATH}; se omite la validación contra catálogo "
            )
            time.sleep(1)

    # Exportar a Excel
    output_path = 'data/output/Multispectral_Acquisition_Feasibility.xlsx'
    exporter = ExcelExporter(output_path, framework_version=settings['framework']['version'])

    # Limpiar datos para compatibilidad con Excel
    df_final = df_final.replace([np.inf, -np.inf], np.nan)

    # Limpiar timezones de las columnas de fecha
    for col in df_final.columns:
        if 'UTC' in col or 'Epoch' in col:
            df_final[col] = pd.to_datetime(df_final[col], errors='coerce')
            df_final[col] = df_final[col].apply(
                lambda x: x.replace(tzinfo=None) if pd.notna(x) and hasattr(x, 'tzinfo') and x.tzinfo is not None else x
            )

    # Parámetros para el reporte
    input_params = {
        'AOI_Name': aoi_config['name'],
        'AOI_Latitude_deg': aoi_config['lat'],
        'AOI_Longitude_deg': aoi_config['lon'],
        'AOI_Radius_km': aoi_config['radius_km'],
        'Start_UTC': start_utc,
        'End_UTC': end_utc,
        'Step_seconds': step_seconds,
        'Satellites': ', '.join([s[1] for s in satellites_to_process])
    }

    success = exporter.generate_report(df_final, input_params, sensors, settings)

    if success:
        logger.info(f"\n✅ ¡ÉXITO! Reporte generado en: {os.path.abspath(output_path)}")
        time.sleep(1)
        logger.info("Abre el archivo Excel para ver el Dashboard completo.")
        time.sleep(1)
    else:
        logger.error("❌ Error al generar el reporte Excel.")
        time.sleep(1)


if __name__ == "__main__":
    run_framework_multi_satellite()
