#Este código es para comprobar que las ventanas sean detectadas para un buen funcionamiento del programa.
import logging
import os
import sys
import time
from datetime import datetime, timedelta, timezone

os.makedirs('data/output', exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

from src.config_manager import get_sensors
from src.orbit_propagator import propagate_orbit
from src.sensor_coverage import haversine_distance_km
from src.tle_downloader import download_tle_from_celestrak
from src.tle_loader import load_and_validate_tle


def diagnosticar():
    """Código de diagnóstico para conocer el porqué no se detectan ventanas."""

    logger.info("="*70)
    logger.info("DIAGNÓSTICO DE DETECCIÓN DE VENTANAS")
    logger.info("Por favor, espere un momento mientras se realiza el análisis...")
    logger.info("="*70)

    time.sleep(2) 

    #Configuración
    sensors = get_sensors()
    sensor_key = 'landsat_8_oli'
    sensor_config = sensors['sensors'][sensor_key]

    aoi_lat = 40.4168  # Madrid, centro aproximado de la ciudad 
    aoi_lon = -3.7038
    aoi_radius_km = 15.0

    # Descargar los tle
    tle_line1, tle_line2 = download_tle_from_celestrak("LANDSAT 8")

    if tle_line1 is None:
        logger.error("No fué posible descargar el TLE")
        return

    # Es necesario usar algunas fechas cercanas a la época de los TLE
    # Cuando hablo de Fechas me refiero a usar fechas cercanas a la época del TLE
    # Primero cargar el TLE para identificar la época
    now = datetime.now(timezone.utc)
    tle_data, tle_age = load_and_validate_tle(tle_line1, tle_line2, now)

    logger.info(f"\nÉpoca del TLE: {tle_data.epoch_utc.strftime('%Y-%m-%d %H:%M:%S')} UTC")
    logger.info(f"Antigüedad del TLE: {tle_age:.1f} días")

    # Solo usar un periodo de 3 días alrededor de la época del TLE
    start_utc = tle_data.epoch_utc - timedelta(days=1)
    end_utc = tle_data.epoch_utc + timedelta(days=2)

    logger.info(f"\nPeríodo de evaluación: {start_utc.strftime('%Y-%m-%d')} a {end_utc.strftime('%Y-%m-%d')}")
    logger.info(f"AOI: Madrid (Lat: {aoi_lat}°, Lon: {aoi_lon}°)")
    logger.info(f"Swath del sensor: {sensor_config['swath_width_km']} km")
    logger.info(f"Radio de AOI: {aoi_radius_km} km\n")

#............ Propagación de órbita y cálculo de distancias..........................
    logger.info("Propagando órbita...")
    logger.info("Por favro espere un momento")
    df_prop = propagate_orbit(tle_data, start_utc, end_utc, 10, aoi_lat, aoi_lon)

    time.sleep(2)

    if df_prop.empty:
        logger.error("No se lograron generar datos de propagación")
        return

    logger.info(f"\nDatos de propagación generados: {len(df_prop)} puntos")
    logger.info(f"Rango de latitud del satélite: {df_prop['sat_lat_deg'].min():.2f}° a {df_prop['sat_lat_deg'].max():.2f}°")
    logger.info(f"Rango de longitud del satélite: {df_prop['sat_lon_deg'].min():.2f}° a {df_prop['sat_lon_deg'].max():.2f}°")

    time.sleep(2)

    # Calculo de distancia a mad tiene que estar vectorizado q es haversine_distance_km
    df_prop['distancia_a_madrid_km'] = haversine_distance_km(
        df_prop['sat_lat_deg'].values, df_prop['sat_lon_deg'].values,
        aoi_lat, aoi_lon
    )

    min_dist = df_prop['distancia_a_madrid_km'].min()
    max_dist = df_prop['distancia_a_madrid_km'].max()
    mean_dist = df_prop['distancia_a_madrid_km'].mean()

    time.sleep(2)

    logger.info("\n--- ESTADÍSTICAS DE DISTANCIA A MADRID ---")
    logger.info(f"La distancia mínima es: {min_dist:.2f} km")
    logger.info(f"La distancia máxima es: {max_dist:.2f} km")
    logger.info(f"La distancia mediae s: {mean_dist:.2f} km")

    time.sleep(2)

    #  cuántos puntos están dentro del swath
    half_swath = sensor_config['swath_width_km'] / 2.0
    threshold = half_swath + aoi_radius_km

    puntos_dentro = len(df_prop[df_prop['distancia_a_madrid_km'] <= threshold])
    puntos_fuera = len(df_prop[df_prop['distancia_a_madrid_km'] > threshold])

    logger.info("\n--- ..................... ---")
    logger.info("\n--- ANÁLISIS DE COBERTURA ---")
    logger.info("\n--- ..................... ---")
    time.sleep(2)
    logger.info(f"Half swath: {half_swath} km")
    logger.info(f"Umbral de cobertura (half_swath + aoi_radius): {threshold} km")
    logger.info(f"Puntos DENTRO del swath: {puntos_dentro} ({puntos_dentro/len(df_prop)*100:.1f}%)")
    logger.info(f"Puntos FUERA del swath: {puntos_fuera} ({puntos_fuera/len(df_prop)*100:.1f}%)")

    time.sleep(2)

    if puntos_dentro == 0:
        logger.warning("\n⚠️  PROBLEMA DETECTADO: Ningún punto está dentro del swath")
        logger.warning("Posibles causas:")
        logger.warning("  1. El satélite no pasa sobre Madrid en este período")
        logger.warning("  2. La época del TLE es muy antigua y la propagación es inexacta")
        logger.warning("  3. Hay un bug en el cálculo de distancia")

        time.sleep(5)

        
        logger.info("\n--- 10 PUNTOS MÁS CERCANOS A MADRID ---")
        df_cercanos = df_prop.nsmallest(10, 'distancia_a_madrid_km')
        for idx, row in df_cercanos.iterrows():
            logger.info(f"  {row['utc_time'].strftime('%Y-%m-%d %H:%M:%S')} - "
                       f"Sat: ({row['sat_lat_deg']:.2f}°, {row['sat_lon_deg']:.2f}°) - "
                       f"Dist: {row['distancia_a_madrid_km']:.2f} km - "
                       f"Elev: {row['elevation_deg']:.1f}°")
            time.sleep(0.5)
    else:
        logger.info(f"\n✓ Se encontraron {puntos_dentro} puntos dentro del swath")
        logger.info("El problema puede estar en la lógica de detección de ventanas")

        time.sleep(5)

        df_dentro = df_prop[df_prop['distancia_a_madrid_km'] <= threshold]
        logger.info("\n--- MUESTRA DE PUNTOS DENTRO DEL SWATH ---")
        for idx, row in df_dentro.head(5).iterrows():
            logger.info(f"  {row['utc_time'].strftime('%Y-%m-%d %H:%M:%S')} - "
                       f"Sat: ({row['sat_lat_deg']:.2f}°, {row['sat_lon_deg']:.2f}°) - "
                       f"Dist: {row['distancia_a_madrid_km']:.2f} km - "
                       f"Elev: {row['elevation_deg']:.1f}°")
            time.sleep(0.5)
if __name__ == "__main__":
    diagnosticar()
